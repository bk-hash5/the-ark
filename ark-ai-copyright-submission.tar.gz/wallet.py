"""
Wallet system for The Ark AI.
Users create a wallet, top up via Lightning, and spend balance on tasks.
Wallet ID stored in browser localStorage — no signup needed.
"""
import os
import json
import time
import uuid
import httpx
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
try:
    import sys; sys.path.insert(0, '/opt/bitcoin-agent/data')
    from tracking import track_event
except ImportError:
    def track_event(*a, **kw): pass

WALLETS_DB = "/opt/bitcoin-agent/data/wallets.json"
MIN_TOPUP_SATS = 10
DEFAULT_TOPUP_SATS = 500


def _load_wallets():
    if os.path.exists(WALLETS_DB):
        with open(WALLETS_DB, "r") as f:
            return json.load(f)
    return {}


def _save_wallets(data):
    os.makedirs(os.path.dirname(WALLETS_DB), exist_ok=True)
    with open(WALLETS_DB, "w") as f:
        json.dump(data, f, indent=2)


def _gen_wallet_id():
    return f"ark-{uuid.uuid4().hex[:12]}"


def wallet_deduct(wallet_id, amount_sats):
    """Deduct sats from wallet. Returns True if successful."""
    wallets = _load_wallets()
    w = wallets.get(wallet_id)
    if not w or w.get("balance_sats", 0) < amount_sats:
        return False
    w["balance_sats"] -= amount_sats
    w["total_spent_sats"] = w.get("total_spent_sats", 0) + amount_sats
    w["total_tasks"] = w.get("total_tasks", 0) + 1
    w["last_used"] = time.time()
    _save_wallets(wallets)
    return True


def wallet_balance(wallet_id):
    """Get wallet balance. Returns None if wallet doesn't exist."""
    wallets = _load_wallets()
    w = wallets.get(wallet_id)
    if not w:
        return None
    return w.get("balance_sats", 0)


def register_wallet_routes(app, cfg_func, lnbits_create_invoice_func, logger):
    """Register wallet routes on the FastAPI app."""

    @app.post("/wallet/create")
    async def create_wallet(request: Request):
        """Create a new wallet and return a Lightning invoice to fund it."""
        body = {}
        try:
            body = await request.json()
        except:
            pass
        amount_sats = body.get("amount_sats", DEFAULT_TOPUP_SATS)
        if amount_sats < MIN_TOPUP_SATS:
            raise HTTPException(400, f"Minimum top-up is {MIN_TOPUP_SATS} sats.")

        wallet_id = _gen_wallet_id()

        webhook_url = cfg_func("lnbits", "webhook_url")
        inv = await lnbits_create_invoice_func(amount_sats, f"Ark Wallet: {amount_sats} sats", webhook=webhook_url)

        wallets = _load_wallets()
        wallets[wallet_id] = {
            "balance_sats": 0,
            "total_spent_sats": 0,
            "total_tasks": 0,
            "created_at": time.time(),
            "last_used": None,
            "pending_topups": [{
                "payment_hash": inv["payment_hash"],
                "amount_sats": amount_sats,
                "created_at": time.time(),
            }],
        }
        _save_wallets(wallets)

        try:
            track_event(request.client.host, "wallet_created", str(amount_sats))
        except: pass

        return {
            "wallet_id": wallet_id,
            "invoice": inv["payment_request"],
            "amount_sats": amount_sats,
            "payment_hash": inv["payment_hash"],
            "status_url": f"/wallet/{wallet_id}/check/{inv['payment_hash']}",
        }

    @app.post("/wallet/{wallet_id}/topup")
    async def topup_wallet(wallet_id: str, request: Request):
        """Top up an existing wallet."""
        wallets = _load_wallets()
        if wallet_id not in wallets:
            raise HTTPException(404, "Wallet not found.")

        body = {}
        try:
            body = await request.json()
        except:
            pass
        amount_sats = body.get("amount_sats", DEFAULT_TOPUP_SATS)
        if amount_sats < MIN_TOPUP_SATS:
            raise HTTPException(400, f"Minimum top-up is {MIN_TOPUP_SATS} sats.")

        webhook_url = cfg_func("lnbits", "webhook_url")
        inv = await lnbits_create_invoice_func(amount_sats, f"Ark Top-up: {amount_sats} sats", webhook=webhook_url)

        if "pending_topups" not in wallets[wallet_id]:
            wallets[wallet_id]["pending_topups"] = []
        wallets[wallet_id]["pending_topups"].append({
            "payment_hash": inv["payment_hash"],
            "amount_sats": amount_sats,
            "created_at": time.time(),
        })
        _save_wallets(wallets)

        return {
            "invoice": inv["payment_request"],
            "amount_sats": amount_sats,
            "payment_hash": inv["payment_hash"],
            "current_balance": wallets[wallet_id]["balance_sats"],
            "status_url": f"/wallet/{wallet_id}/check/{inv['payment_hash']}",
        }

    @app.get("/wallet/{wallet_id}/check/{payment_hash}")
    async def check_wallet_payment(wallet_id: str, payment_hash: str):
        """Check if a wallet top-up payment has been confirmed."""
        wallets = _load_wallets()
        if wallet_id not in wallets:
            raise HTTPException(404, "Wallet not found.")

        w = wallets[wallet_id]

        # Find the pending top-up
        pending = [p for p in w.get("pending_topups", []) if p["payment_hash"] == payment_hash]
        if not pending:
            # Already processed or not found
            return {"status": "complete", "balance_sats": w["balance_sats"]}

        # Check LNbits for payment
        try:
            lnbits_url = cfg_func("lnbits", "url")
            lnbits_key = cfg_func("lnbits", "api_key")
            async with httpx.AsyncClient(timeout=10) as client:
                r = await client.get(
                    f"{lnbits_url}/api/v1/payments/{payment_hash}",
                    headers={"X-Api-Key": lnbits_key},
                )
                if r.status_code == 200 and r.json().get("paid"):
                    # Credit the wallet
                    amount = pending[0]["amount_sats"]
                    w["balance_sats"] = w.get("balance_sats", 0) + amount
                    w["pending_topups"] = [p for p in w.get("pending_topups", []) if p["payment_hash"] != payment_hash]
                    _save_wallets(wallets)
                    logger.info(f"Wallet {wallet_id} credited {amount} sats. Balance: {w['balance_sats']}")
                    try:
                        track_event("wallet:" + wallet_id, "wallet_topup", str(amount))
                    except: pass
                    return {"status": "complete", "balance_sats": w["balance_sats"], "credited": amount}
        except Exception as e:
            logger.error(f"Wallet payment check error: {e}")

        return {"status": "pending", "balance_sats": w["balance_sats"]}

    @app.get("/wallet/{wallet_id}/balance")
    async def get_wallet_balance(wallet_id: str):
        """Get wallet balance and stats."""
        wallets = _load_wallets()
        if wallet_id not in wallets:
            raise HTTPException(404, "Wallet not found.")
        w = wallets[wallet_id]
        return {
            "wallet_id": wallet_id,
            "balance_sats": w.get("balance_sats", 0),
            "total_spent_sats": w.get("total_spent_sats", 0),
            "total_tasks": w.get("total_tasks", 0),
        }

    @app.get("/wallet-stats")
    async def wallet_stats():
        """Admin endpoint: wallet activity overview."""
        wallets = _load_wallets()
        total_wallets = len(wallets)
        total_balance = sum(w.get("balance_sats", 0) for w in wallets.values())
        total_spent = sum(w.get("total_spent_sats", 0) for w in wallets.values())
        total_tasks = sum(w.get("total_tasks", 0) for w in wallets.values())
        active_wallets = sum(1 for w in wallets.values() if w.get("total_tasks", 0) > 0)
        funded_wallets = sum(1 for w in wallets.values() if w.get("balance_sats", 0) > 0)

        return {
            "total_wallets": total_wallets,
            "funded_wallets": funded_wallets,
            "active_wallets": active_wallets,
            "total_balance_sats": total_balance,
            "total_spent_sats": total_spent,
            "total_tasks": total_tasks,
            "wallets": [
                {
                    "id": wid[:8] + "...",
                    "balance": w.get("balance_sats", 0),
                    "spent": w.get("total_spent_sats", 0),
                    "tasks": w.get("total_tasks", 0),
                    "created": w.get("created_at"),
                    "last_used": w.get("last_used"),
                }
                for wid, w in wallets.items()
            ]
        }

    logger.info("Wallet routes registered at /wallet/")
