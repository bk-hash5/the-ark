"""
OpenAI-compatible API for The Ark AI.
Drop-in replacement for OpenAI API — works with Cursor, Cline, OpenWebUI, etc.

Endpoints:
  POST /v1/chat/completions  — Chat completions (OpenAI format)
  GET  /v1/models            — List available models
  POST /v1/api-keys          — Create API key (returns Lightning invoice)
  GET  /v1/api-keys/balance  — Check balance
  POST /v1/api-keys/topup    — Top up balance (returns Lightning invoice)
"""
import os
import json
import time
import uuid
import hashlib
import httpx
from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse, StreamingResponse
import asyncio

# ── Config ──────────────────────────────────────────────────────────────────
API_KEYS_DB = "/opt/bitcoin-agent/data/api_keys.json"
COST_PER_INPUT_TOKEN = 0.00000013   # $0.13/M tokens (Qwen3 on DeepInfra)
COST_PER_OUTPUT_TOKEN = 0.00000060  # $0.60/M tokens
SATS_PER_DOLLAR = 10000             # ~$100k/BTC → 10,000 sats/dollar (rough)
MIN_TOPUP_SATS = 10               # Minimum top-up: 100 sats
DEFAULT_TOPUP_SATS = 1000          # Default top-up: 1000 sats

# Model mapping — our model exposed as friendly names
MODEL_MAP = {
    "ark-1": "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "qwen3-235b": "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "default": "Qwen/Qwen3-235B-A22B-Instruct-2507",
}

MODEL_INFO = [
    {
        "id": "ark-1",
        "object": "model",
        "created": 1709251200,
        "owned_by": "the-ark-ai",
        "description": "Qwen3 235B — fast, capable, multilingual. Default model.",
    },
    {
        "id": "qwen3-235b",
        "object": "model",
        "created": 1709251200,
        "owned_by": "the-ark-ai",
        "description": "Alias for ark-1 (Qwen3 235B).",
    },
]


# ── API Key Management ─────────────────────────────────────────────────────
def _load_keys():
    if os.path.exists(API_KEYS_DB):
        with open(API_KEYS_DB, "r") as f:
            return json.load(f)
    return {}


def _save_keys(data):
    os.makedirs(os.path.dirname(API_KEYS_DB), exist_ok=True)
    with open(API_KEYS_DB, "w") as f:
        json.dump(data, f, indent=2)


def _generate_api_key():
    raw = uuid.uuid4().hex
    return f"sk-ark-{raw}"


def _authenticate(request: Request):
    """Extract and validate API key from Authorization header."""
    auth = request.headers.get("authorization", "")
    if not auth.startswith("Bearer "):
        raise HTTPException(401, {"error": {"message": "Missing API key. Include 'Authorization: Bearer sk-ark-...' header.", "type": "auth_error", "code": "missing_api_key"}})
    key = auth[7:].strip()
    keys = _load_keys()
    if key not in keys:
        raise HTTPException(401, {"error": {"message": "Invalid API key.", "type": "auth_error", "code": "invalid_api_key"}})
    return key, keys[key]


def _deduct_balance(api_key, input_tokens, output_tokens):
    """Deduct token cost from API key balance. Returns cost in sats."""
    cost_usd = (input_tokens * COST_PER_INPUT_TOKEN) + (output_tokens * COST_PER_OUTPUT_TOKEN)
    cost_sats = max(1, int(cost_usd * SATS_PER_DOLLAR))  # Minimum 1 sat
    
    keys = _load_keys()
    if api_key not in keys:
        return 0
    keys[api_key]["balance_sats"] -= cost_sats
    keys[api_key]["total_spent_sats"] += cost_sats
    keys[api_key]["total_requests"] += 1
    keys[api_key]["last_used"] = time.time()
    _save_keys(keys)
    return cost_sats


def _token_estimate(text):
    """Rough token count estimate (4 chars per token)."""
    return max(1, len(text) // 4)


# ── Route Registration ─────────────────────────────────────────────────────
def register_openai_routes(app, cfg_func, lnbits_create_invoice_func, logger):
    """Register OpenAI-compatible routes on the FastAPI app."""

    @app.get("/v1/models")
    async def list_models():
        return {"object": "list", "data": MODEL_INFO}

    @app.post("/v1/api-keys")
    async def create_api_key(request: Request):
        """Create a new API key. Returns a Lightning invoice to activate it."""
        body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
        amount_sats = body.get("amount_sats", DEFAULT_TOPUP_SATS)
        if amount_sats < MIN_TOPUP_SATS:
            raise HTTPException(400, {"error": {"message": f"Minimum top-up is {MIN_TOPUP_SATS} sats.", "type": "invalid_request"}})

        api_key = _generate_api_key()
        
        # Create Lightning invoice
        webhook_url = cfg_func("lnbits", "webhook_url")
        inv = await lnbits_create_invoice_func(amount_sats, f"Ark API Key: {amount_sats} sats", webhook=webhook_url)
        
        # Store key as pending (activated on payment)
        keys = _load_keys()
        keys[api_key] = {
            "balance_sats": 0,
            "total_spent_sats": 0,
            "total_requests": 0,
            "created_at": time.time(),
            "last_used": None,
            "status": "pending_payment",
            "pending_payment_hash": inv["payment_hash"],
            "pending_amount": amount_sats,
        }
        _save_keys(keys)

        return {
            "api_key": api_key,
            "status": "pending_payment",
            "invoice": inv["payment_request"],
            "amount_sats": amount_sats,
            "payment_hash": inv["payment_hash"],
            "message": f"Pay the Lightning invoice to activate your API key with {amount_sats} sats balance.",
            "check_status": f"/v1/api-keys/status?payment_hash={inv['payment_hash']}",
        }

    @app.get("/v1/api-keys/status")
    async def api_key_status(payment_hash: str):
        """Check if API key payment has been confirmed."""
        keys = _load_keys()
        for key, data in keys.items():
            if data.get("pending_payment_hash") == payment_hash:
                if data["status"] == "active":
                    return {"status": "active", "balance_sats": data["balance_sats"], "api_key_preview": key[:12] + "..."}
                # Check payment
                try:
                    lnbits_url = cfg_func("lnbits", "url")
                    lnbits_key = cfg_func("lnbits", "api_key")
                    async with httpx.AsyncClient(timeout=10) as client:
                        r = await client.get(
                            f"{lnbits_url}/api/v1/payments/{payment_hash}",
                            headers={"X-Api-Key": lnbits_key},
                        )
                        if r.status_code == 200 and r.json().get("paid"):
                            data["status"] = "active"
                            data["balance_sats"] = data.get("pending_amount", DEFAULT_TOPUP_SATS)
                            data.pop("pending_payment_hash", None)
                            data.pop("pending_amount", None)
                            _save_keys(keys)
                            return {"status": "active", "balance_sats": data["balance_sats"], "api_key": key}
                except Exception as e:
                    logger.error(f"API key payment check error: {e}")
                return {"status": "pending_payment"}
        raise HTTPException(404, {"error": {"message": "Payment hash not found.", "type": "not_found"}})

    @app.get("/v1/api-keys/balance")
    async def check_balance(request: Request):
        api_key, data = _authenticate(request)
        return {
            "balance_sats": data["balance_sats"],
            "total_spent_sats": data["total_spent_sats"],
            "total_requests": data["total_requests"],
        }

    @app.post("/v1/api-keys/topup")
    async def topup_balance(request: Request):
        """Top up an existing API key."""
        api_key, data = _authenticate(request)
        body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
        amount_sats = body.get("amount_sats", DEFAULT_TOPUP_SATS)
        if amount_sats < MIN_TOPUP_SATS:
            raise HTTPException(400, {"error": {"message": f"Minimum top-up is {MIN_TOPUP_SATS} sats."}})

        webhook_url = cfg_func("lnbits", "webhook_url")
        inv = await lnbits_create_invoice_func(amount_sats, f"Ark API Top-up: {amount_sats} sats", webhook=webhook_url)

        # Store pending top-up
        keys = _load_keys()
        if "pending_topups" not in keys[api_key]:
            keys[api_key]["pending_topups"] = []
        keys[api_key]["pending_topups"].append({
            "payment_hash": inv["payment_hash"],
            "amount_sats": amount_sats,
            "created_at": time.time(),
        })
        _save_keys(keys)

        return {
            "invoice": inv["payment_request"],
            "amount_sats": amount_sats,
            "payment_hash": inv["payment_hash"],
            "current_balance": data["balance_sats"],
            "check_status": f"/v1/api-keys/status?payment_hash={inv['payment_hash']}",
        }

    @app.post("/v1/chat/completions")
    async def chat_completions(request: Request):
        """OpenAI-compatible chat completions endpoint."""
        api_key, key_data = _authenticate(request)
        
        if key_data.get("status") != "active":
            raise HTTPException(402, {"error": {"message": "API key not yet activated. Pay the invoice first.", "type": "payment_required"}})

        if key_data["balance_sats"] <= 0:
            raise HTTPException(402, {"error": {"message": "Insufficient balance. Top up at POST /v1/api-keys/topup", "type": "insufficient_balance", "balance_sats": key_data["balance_sats"]}})

        body = await request.json()
        messages = body.get("messages", [])
        if not messages:
            raise HTTPException(400, {"error": {"message": "messages is required.", "type": "invalid_request"}})

        requested_model = body.get("model", "ark-1")
        actual_model = MODEL_MAP.get(requested_model, MODEL_MAP["default"])
        
        max_tokens = body.get("max_tokens") or body.get("max_completion_tokens") or 4096
        temperature = body.get("temperature", 0.7)
        stream = body.get("stream", False)
        
        # Get LLM config
        llm_config = {
            "base_url": cfg_func("llm", "base_url"),
            "api_key": cfg_func("llm", "api_key"),
        }

        # Forward to DeepInfra
        deepinfra_body = {
            "model": actual_model,
            "messages": messages,
            "max_tokens": min(max_tokens, 8192),
            "temperature": temperature,
            "stream": stream,
        }
        
        # Pass through supported params
        for param in ["top_p", "frequency_penalty", "presence_penalty", "stop", "n"]:
            if param in body:
                deepinfra_body[param] = body[param]

        headers = {
            "Authorization": f"Bearer {llm_config['api_key']}",
            "Content-Type": "application/json",
        }

        if stream:
            return await _stream_response(llm_config["base_url"], headers, deepinfra_body, api_key, requested_model)
        
        # Non-streaming
        async with httpx.AsyncClient(timeout=120) as client:
            resp = await client.post(
                f"{llm_config['base_url']}/chat/completions",
                json=deepinfra_body,
                headers=headers,
            )
        
        if resp.status_code != 200:
            logger.error(f"DeepInfra error: {resp.status_code} {resp.text[:200]}")
            raise HTTPException(502, {"error": {"message": "Upstream model error.", "type": "upstream_error"}})

        result = resp.json()
        
        # Deduct balance
        usage = result.get("usage", {})
        input_tokens = usage.get("prompt_tokens", 0)
        output_tokens = usage.get("completion_tokens", 0)
        cost_sats = _deduct_balance(api_key, input_tokens, output_tokens)

        # Reformat response to standard OpenAI format
        response = {
            "id": result.get("id", f"chatcmpl-{uuid.uuid4().hex[:12]}"),
            "object": "chat.completion",
            "created": result.get("created", int(time.time())),
            "model": requested_model,
            "choices": result.get("choices", []),
            "usage": {
                "prompt_tokens": input_tokens,
                "completion_tokens": output_tokens,
                "total_tokens": input_tokens + output_tokens,
            },
            "x_ark": {
                "cost_sats": cost_sats,
                "balance_remaining": _load_keys().get(api_key, {}).get("balance_sats", 0),
            },
        }
        return JSONResponse(response)

    async def _stream_response(base_url, headers, body, api_key, model_name):
        """Stream SSE response, deducting balance at the end."""
        total_output_tokens = 0
        input_tokens = 0

        async def generate():
            nonlocal total_output_tokens, input_tokens
            async with httpx.AsyncClient(timeout=120) as client:
                async with client.stream(
                    "POST",
                    f"{base_url}/chat/completions",
                    json=body,
                    headers=headers,
                ) as resp:
                    if resp.status_code != 200:
                        error_text = ""
                        async for chunk in resp.aiter_text():
                            error_text += chunk
                        yield f"data: {json.dumps({'error': {'message': 'Upstream error', 'type': 'upstream_error'}})}\n\n"
                        yield "data: [DONE]\n\n"
                        return

                    async for line in resp.aiter_lines():
                        if line.startswith("data: "):
                            data_str = line[6:]
                            if data_str.strip() == "[DONE]":
                                # Deduct balance
                                # Estimate input tokens from messages
                                input_text = json.dumps(body.get("messages", []))
                                input_tokens = _token_estimate(input_text)
                                _deduct_balance(api_key, input_tokens, total_output_tokens)
                                yield "data: [DONE]\n\n"
                                break
                            try:
                                chunk_data = json.loads(data_str)
                                # Count output tokens
                                choices = chunk_data.get("choices", [])
                                for c in choices:
                                    delta = c.get("delta", {})
                                    if delta.get("content"):
                                        total_output_tokens += _token_estimate(delta["content"])
                                # Replace model name
                                chunk_data["model"] = model_name
                                yield f"data: {json.dumps(chunk_data)}\n\n"
                            except json.JSONDecodeError:
                                yield f"{line}\n"
                        elif line.strip():
                            yield f"{line}\n"

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    logger.info("OpenAI-compatible API routes registered at /v1/")
