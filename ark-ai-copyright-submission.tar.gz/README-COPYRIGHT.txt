================================================================================
THE ARK AI — SOURCE CODE COPYRIGHT REGISTRATION
================================================================================

Title:          The Ark AI — Bitcoin Lightning AI Service Platform
Author:         [Navigator — to be filled with legal name]
Date Created:   February 20, 2026
Date Published: February 20, 2026 (first public deployment)
Category:       Computer Program (Software / Source Code)
Language:       Python 3.12
ISBN:           N/A (not applicable — this is software, not a publication)

================================================================================
DESCRIPTION OF WORK
================================================================================

The Ark AI is an original software platform that provides artificial
intelligence services accessible via Bitcoin Lightning Network micropayments.
The platform enables users to access 143+ AI-powered services including text
generation, image creation and editing, document generation, code assistance,
translation, and voice synthesis — all payable through Bitcoin Lightning
invoices or a built-in satoshi wallet system.

The software implements a novel pay-per-task model using the L402 (Lightning
HTTP 402) protocol, eliminating the need for traditional subscriptions. Users
can pay as little as 10 satoshis (fractions of a cent) per task.

================================================================================
TECHNICAL ARCHITECTURE
================================================================================

The software consists of the following original components:

1. server.py (2,608 lines) — Core API server built with FastAPI framework.
   Implements task routing, streaming responses (Server-Sent Events),
   Lightning invoice generation, wallet management, free trial system with
   IP/fingerprint tracking, and PDF document generation pipeline.

2. llm_tasks.py (746 lines) — AI task execution engine supporting 143+
   service types. Implements prompt engineering, multi-model routing
   (text and image models), image generation/editing, voice synthesis,
   African language support, and style transfer capabilities.

3. pdf_gen.py (140 lines) — PDF document generation module that converts
   AI-generated content into professionally formatted, branded PDF
   documents with headers, footers, and structured typography.

4. wallet.py — Bitcoin Lightning wallet system enabling users to maintain
   satoshi balances, top up via Lightning invoices, and pay for services
   without per-task invoice generation.

5. openai_compat.py — OpenAI-compatible API layer allowing third-party
   applications to connect using standard OpenAI client libraries.

6. workflows.py — Multi-step task orchestration engine for complex
   AI workflows requiring sequential processing.

7. config.yaml — Service configuration defining pricing (in satoshis),
   model selection, and operational parameters for all 143+ services.

Total: ~3,500 lines of original Python source code across 12 modules.

================================================================================
ORIGINAL ELEMENTS
================================================================================

The following elements are original creative works by the author:

- The complete software architecture and system design
- The pay-per-task Lightning payment integration model
- The free trial system with IP and browser fingerprint tracking
- The automatic PDF generation pipeline for AI-generated documents
- The 143+ AI service definitions and prompt engineering
- The wallet-based micropayment system
- The task auto-detection and routing algorithms
- The African language voice synthesis integration
- All HTML/CSS/JavaScript frontend code (not included in this submission
  but deployed at arknode.ai)
- The Ark AI branding, logo, and visual identity

================================================================================
DEPLOYMENT
================================================================================

The software is publicly accessible at:
- https://arknode.ai (primary domain)
- https://thenode.it.com (secondary domain)

Source repository: Private (not open source)
Server: DigitalOcean VPS, Ubuntu 24.04

================================================================================
