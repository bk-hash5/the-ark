"""
Bitcoin AI Agent Server
FastAPI server with L402 Lightning payment gating.

Usage:
    python server.py                    # uses config.yaml
    LNBITS_URL=... python server.py     # env overrides
"""

import os
import sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "../data"))
from tracking import track_event, get_report
import sys
import time
import json
import hmac
import hashlib
import base64
import logging
import secrets
import sqlite3
import threading
from pathlib import Path
from typing import Any, Optional

import httpx
import yaml
from dotenv import load_dotenv
from fastapi import FastAPI, Request, Response, HTTPException
from fastapi.responses import JSONResponse
from fastapi.responses import FileResponse as _FileResp
from pydantic import BaseModel
from pdf_gen import generate_pdf, PDF_ELIGIBLE_TASKS, cleanup_old_pdfs, PDF_DIR

from workflows import WORKFLOWS
MAX_INPUT_LENGTH = 50000  # 50KB max input
MAX_TASK_INPUT = 100000  # 100KB for research tasks

from llm_tasks import execute_task as _execute_task_raw, estimate_price, TASK_TYPES, text_to_speech, generate_image, edit_image, african_text_to_speech, african_transcribe, AFRICAN_TTS_VOICES, AFRICAN_TTS_LANGUAGES, image_variation, image_upscale, image_bg_remove, image_colorize, image_restore, image_style_transfer
from llm_tasks import get_model_for_task, FAST_MODEL, POWER_MODEL, POWER_TASKS
from openai_compat import register_openai_routes
from wallet import register_wallet_routes, wallet_deduct, wallet_balance

def _auto_refund(client_ip, amount_sats, payment_hash, reason="task_failure"):
    """Auto-credit a user when their paid task fails."""
    import json, time
    credits_file = "/opt/bitcoin-agent/data/credits.json"
    try:
        try:
            with open(credits_file, "r") as f:
                credits = json.load(f)
        except FileNotFoundError:
            credits = {}
        if client_ip in credits:
            credits[client_ip]["credit_sats"] += amount_sats
        else:
            credits[client_ip] = {
                "credit_sats": amount_sats,
                "reason": reason,
                "payment_hash": payment_hash,
                "created_at": time.time(),
        "client_ip": client_ip,
            }
        with open(credits_file, "w") as f:
            json.dump(credits, f, indent=2)
        logger.info(f"Auto-refund: {amount_sats} sats credited to {client_ip} (hash: {payment_hash[:16]}...)")
        return True
    except Exception as e:
        logger.error(f"Auto-refund failed: {e}")
        return False

_LEGAL_TASKS = {"contract_analysis", "law_research", "document_template", "nda_template", "regulatory_research"}
_MEDICAL_TASKS = {"health_lit_review", "clinical_notes_format", "pharma_research", "health_simplify", "health_research"}
_LEGAL_DISCLAIMER = "\n\n---\n⚠️ **Disclaimer:** This is AI-generated general research content for informational and educational purposes only. It does NOT constitute legal advice and should NOT be relied upon as such. Laws vary by jurisdiction. Always consult a qualified, licensed attorney for advice specific to your situation. The Ark AI assumes no liability for actions taken based on this content."

import asyncio as _asyncio_locks
_task_locks: dict[str, _asyncio_locks.Lock] = {}

def _get_task_lock(payment_hash: str) -> _asyncio_locks.Lock:
    if payment_hash not in _task_locks:
        _task_locks[payment_hash] = _asyncio_locks.Lock()
    return _task_locks[payment_hash]

_MEDICAL_DISCLAIMER = "\n\n---\n⚠️ **Disclaimer:** This is AI-generated general research content for informational and educational purposes only. It does NOT constitute medical advice, diagnosis, or treatment. Always seek the advice of a qualified healthcare provider with any questions regarding a medical condition. Never disregard professional medical advice or delay seeking it because of AI-generated content. The Ark AI assumes no liability for actions taken based on this content."

_FINANCIAL_TASKS = {"tax_summary", "invoice_format", "financial_report", "expense_categorize", "audit_prep"}
_FINANCIAL_DISCLAIMER = "\n\n---\n\u26a0\ufe0f **Disclaimer:** AI-generated content for informational purposes only. Not financial advice. Consult a qualified financial professional for your specific situation."

_CODE_TASKS = {"code_gen", "code_review", "bug_finder", "unit_test", "security_scan", "secret_scanner", "dockerfile_gen", "cicd_gen", "nginx_gen", "compose_gen", "terraform_gen", "k8s_gen", "html_css_gen", "schema_design", "api_design", "langgraph_gen", "langchain_gen", "agent_design", "multi_agent_gen"}
_CODE_DISCLAIMER = "\n\n---\n\u26a0\ufe0f **Disclaimer:** AI-generated code. Review and test thoroughly before deploying to production."

_SKIP_UNIVERSAL_DISCLAIMER = {"image_gen", "image_create", "image_edit", "image_variation", "image_upscale", "image_bg_remove", "image_colorize", "image_restore", "image_style", "image_caption", "image_logo", "image_mockup", "image_meme", "image_avatar", "image_banner", "image_thumbnail", "image_infographic", "image_qr_art", "image_portrait", "image_product", "image_landscape", "image_sticker", "image_icon", "voice_gen", "voice_read", "voice_narrate", "african_tts", "african_transcribe"}

# === Referral System ===
import json as _json_ref
import time as _time_ref
import random as _random_ref
import string as _string_ref

REFERRAL_DB = "/opt/bitcoin-agent/data/referrals.json"

def _load_referrals():
    if os.path.exists(REFERRAL_DB):
        with open(REFERRAL_DB, 'r') as f:
            return _json_ref.load(f)
    return {"referrers": {}, "referred": {}}

def _save_referrals(data):
    os.makedirs(os.path.dirname(REFERRAL_DB), exist_ok=True)
    with open(REFERRAL_DB, 'w') as f:
        _json_ref.dump(data, f, indent=2)

def _gen_ref_code():
    return ''.join(_random_ref.choices(_string_ref.ascii_letters + _string_ref.digits, k=6))

_UNIVERSAL_DISCLAIMER = "\n\n---\n🤖 *This response was generated by AI (The Ark AI). For informational purposes only.*"

async def execute_task(task_type, input_text, llm_config, **kwargs):
    # Voice generation
    if task_type in ("voice_gen", "voice_read", "voice_narrate"):
        voice_map = {"voice_gen": "nova", "voice_read": "onyx", "voice_narrate": "shimmer"}
        voice = kwargs.get("voice", voice_map.get(task_type, "nova"))
        audio_bytes = await text_to_speech(input_text, llm_config, voice=voice)
        class VoiceResult:
            def __init__(self, audio):
                self.content = f"🔊 Voice generated successfully ({len(audio)} bytes). Download your audio from the voice endpoint."
                self.input_tokens = 0
                self.output_tokens = 0
                self.model = "tts-1-hd"
                self.audio_bytes = audio
        return VoiceResult(audio_bytes)
    

    # African language TTS (edge-tts, free, no GPU)
    if task_type == "african_tts":
        import re as _re
        _lang = "swahili"
        _gender = "female"
        _text = input_text
        _lang_match = _re.search(r"language:(\w+)", input_text)
        if _lang_match:
            _lang = _lang_match.group(1)
            _text = _text.replace(_lang_match.group(0), "").strip()
        _gender_match = _re.search(r"gender:(\w+)", input_text)
        if _gender_match:
            _gender = _gender_match.group(1)
            _text = _text.replace(_gender_match.group(0), "").strip()
        if not _text:
            _text = "Habari! Karibu."
        audio_bytes = await african_text_to_speech(_text, language=_lang, gender=_gender)
        class AfricanTTSResult:
            def __init__(self, audio, lang, gender):
                self.content = f"African TTS generated ({lang}, {gender}). {len(audio)} bytes."
                self.input_tokens = 0
                self.output_tokens = 0
                self.model = f"edge-tts-{lang}"
                self.audio_bytes = audio
        return AfricanTTSResult(audio_bytes, _lang, _gender)

    # African language transcription (Whisper API)
    if task_type == "african_transcribe":
        import base64 as _b64
        import re as _re
        _lang_hint = None
        _audio_data = None
        _text = input_text
        _lang_match = _re.search(r"language:(\w+)", _text)
        if _lang_match:
            _lang_hint = _lang_match.group(1)
            _text = _text.replace(_lang_match.group(0), "").strip()
        try:
            _audio_data = _b64.b64decode(_text)
        except Exception:
            pass
        if not _audio_data:
            class TranscribeError:
                def __init__(self):
                    self.content = "Please send base64-encoded audio data. Supported: mp3, wav, m4a, webm. Add language:swahili (or hausa, yoruba, etc.) for better accuracy."
                    self.input_tokens = 0
                    self.output_tokens = 0
                    self.model = "whisper-1"
            return TranscribeError()
        transcription = await african_transcribe(_audio_data, llm_config, language=_lang_hint)
        class TranscribeResult:
            def __init__(self, text, lang):
                self.content = f"Transcription ({lang or 'auto-detected'}):\n\n{text}"
                self.input_tokens = 0
                self.output_tokens = 0
                self.model = "whisper-1"
        return TranscribeResult(transcription, _lang_hint)

    # Image generation
    if task_type in ("image_gen", "image_create"):
        img_data = await generate_image(input_text, llm_config)
        img_url = img_data.get("url", "")
        revised_prompt = img_data.get("revised_prompt", input_text)
        class ImageResult:
            def __init__(self):
                self.content = f"🎨 Image generated!\n\nPrompt: {revised_prompt}\n\nImage URL: {img_url}\n\n(URL expires in 1 hour. Right-click to save.)"
                self.input_tokens = 0
                self.output_tokens = 0
                self.model = "gpt-image-1.5"
                self.image_url = img_url
        return ImageResult()
    
    # Image editing (upload image + prompt to transform it)
    if task_type == "image_edit":
        source_image = kwargs.get("image", "")
        if not source_image:
            class ImageEditError:
                def __init__(self):
                    self.content = "Please upload an image first, then describe how you want to edit it."
                    self.input_tokens = 0
                    self.output_tokens = 0
                    self.model = "gpt-image-1.5"
            return ImageEditError()
        img_data = await edit_image(input_text, source_image, llm_config)
        img_url = img_data.get("url", "")
        class ImageEditResult:
            def __init__(self):
                self.content = f"\U0001f3a8 Image edited!\n\nImage URL: {img_url}\n\n(URL expires in 24 hours. Right-click to save.)"
                self.input_tokens = 0
                self.output_tokens = 0
                self.model = "gpt-image-1.5"
                self.image_url = img_url
        return ImageEditResult()
    
    # --- Image variation (duplicate/modify) ---
    if task_type == "image_variation":
        source_image = kwargs.get("image", "")
        if not source_image:
            class VarErr:
                content = "Please upload an image to create a variation of."
                input_tokens = 0; output_tokens = 0; model = "gpt-image-1"
            return VarErr()
        variation_prompt = input_text if input_text.strip() else "Create a creative variation of this image"
        img_data = await image_variation(source_image, llm_config, variation_prompt)
        img_url = img_data.get("url", "")
        class VarResult:
            content = f"\U0001f504 Image variation created!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return VarResult()
    
    # --- Image upscale/enhance ---
    if task_type == "image_upscale":
        source_image = kwargs.get("image", "")
        if not source_image:
            class UpErr:
                content = "Please upload an image to upscale/enhance."
                input_tokens = 0; output_tokens = 0; model = "gpt-image-1"
            return UpErr()
        img_data = await image_upscale(source_image, llm_config)
        img_url = img_data.get("url", "")
        class UpResult:
            content = f"\u2728 Image enhanced!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return UpResult()
    
    # --- Background removal ---
    if task_type == "image_bg_remove":
        source_image = kwargs.get("image", "")
        if not source_image:
            class BgErr:
                content = "Please upload an image to remove the background from."
                input_tokens = 0; output_tokens = 0; model = "gpt-image-1"
            return BgErr()
        img_data = await image_bg_remove(source_image, llm_config)
        img_url = img_data.get("url", "")
        class BgResult:
            content = f"\u2702\ufe0f Background removed!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return BgResult()
    
    # --- Colorize B&W ---
    if task_type == "image_colorize":
        source_image = kwargs.get("image", "")
        if not source_image:
            class ColErr:
                content = "Please upload a black & white image to colorize."
                input_tokens = 0; output_tokens = 0; model = "gpt-image-1"
            return ColErr()
        img_data = await image_colorize(source_image, llm_config)
        img_url = img_data.get("url", "")
        class ColResult:
            content = f"\U0001f308 Image colorized!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return ColResult()
    
    # --- Photo restoration ---
    if task_type == "image_restore":
        source_image = kwargs.get("image", "")
        if not source_image:
            class ResErr:
                content = "Please upload an old or damaged photo to restore."
                input_tokens = 0; output_tokens = 0; model = "gpt-image-1"
            return ResErr()
        img_data = await image_restore(source_image, llm_config)
        img_url = img_data.get("url", "")
        class ResResult:
            content = f"\U0001f5bc\ufe0f Photo restored!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return ResResult()
    
    # --- Style transfer ---
    if task_type == "image_style":
        source_image = kwargs.get("image", "")
        if not source_image:
            class StErr:
                content = "Please upload an image and specify the style (e.g., oil painting, watercolor, anime, pixel art)."
                input_tokens = 0; output_tokens = 0; model = "gpt-image-1"
            return StErr()
        style = input_text if input_text.strip() else "oil painting"
        img_data = await image_style_transfer(source_image, style, llm_config)
        img_url = img_data.get("url", "")
        class StResult:
            content = f"\U0001f3a8 Style applied: {style}!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return StResult()
    
    # --- Generation-based image tasks (no source image needed) ---
    _IMG_GEN_PREFIXES = {
        "image_logo": "Design a professional, clean, modern logo: ",
        "image_mockup": "Create a professional UI/product mockup: ",
        "image_meme": "Create a funny meme image: ",
        "image_avatar": "Create a stylish profile picture/avatar: ",
        "image_banner": "Create a professional social media banner: ",
        "image_thumbnail": "Create an eye-catching video thumbnail: ",
        "image_infographic": "Create a clear informative infographic: ",
        "image_qr_art": "Create an artistic decorative QR code design: ",
        "image_portrait": "Create a professional portrait photograph: ",
        "image_product": "Create professional product photography: ",
        "image_landscape": "Create a stunning landscape/wallpaper: ",
        "image_sticker": "Design a fun colorful sticker with clean edges: ",
        "image_icon": "Design a clean recognizable app/web icon: ",
    }
    if task_type in _IMG_GEN_PREFIXES:
        prefix = _IMG_GEN_PREFIXES[task_type]
        _sz = "1536x1024" if task_type in ("image_banner", "image_thumbnail", "image_landscape") else "1024x1024"
        img_data = await generate_image(prefix + input_text, llm_config, size=_sz, quality="high")
        img_url = img_data.get("url", "")
        label = task_type.replace("image_", "").replace("_", " ").title()
        class ImgGenResult:
            content = f"\U0001f3a8 {label} created!\n\nImage URL: {img_url}\n\n(URL expires in 24h. Right-click to save.)"
            input_tokens = 0; output_tokens = 0; model = "gpt-image-1"; image_url = img_url
        return ImgGenResult()

    result = await _execute_task_raw(task_type, input_text, llm_config, **kwargs)
    if task_type in _LEGAL_TASKS:
        result.content += _LEGAL_DISCLAIMER
    elif task_type in _MEDICAL_TASKS:
        result.content += _MEDICAL_DISCLAIMER
    elif task_type in _FINANCIAL_TASKS:
        result.content += _FINANCIAL_DISCLAIMER
    elif task_type in _CODE_TASKS:
        result.content += _CODE_DISCLAIMER
    
    # Universal AI disclaimer on all non-image, non-voice tasks
    if task_type not in _SKIP_UNIVERSAL_DISCLAIMER:
        result.content += _UNIVERSAL_DISCLAIMER
    return result

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

load_dotenv()

# ---------------------------------------------------------------------------
# Encryption at rest (Fernet)
# ---------------------------------------------------------------------------
from cryptography.fernet import Fernet as _Fernet

_ENC_KEY_PATH = Path(__file__).parent / ".encryption_key"

def _load_fernet():
    if _ENC_KEY_PATH.exists():
        return _Fernet(_ENC_KEY_PATH.read_bytes().strip())
    return None

_fernet = _load_fernet()

def encrypt_text(text):
    if text is None or _fernet is None:
        return text
    return _fernet.encrypt(text.encode()).decode()

def decrypt_text(text):
    if text is None or _fernet is None:
        return text
    try:
        return _fernet.decrypt(text.encode()).decode()
    except Exception:
        return text  # plaintext fallback

# ---------------------------------------------------------------------------
# Rate limiter for history endpoint
# ---------------------------------------------------------------------------
_history_rate = {}
_history_rate_lock = threading.Lock()

def _check_rate_limit(ip, max_per_min=10):
    now = time.time()
    with _history_rate_lock:
        hits = _history_rate.get(ip, [])
        hits = [t for t in hits if now - t < 60]
        if len(hits) >= max_per_min:
            return False
        hits.append(now)
        _history_rate[ip] = hits
        return True
logger = logging.getLogger("bitcoin-agent")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")

def load_config() -> dict:
    """Load config from config.yaml, with env var overrides."""
    cfg_path = Path(__file__).parent / "config.yaml"
    cfg: dict[str, Any] = {}
    if cfg_path.exists():
        cfg = yaml.safe_load(cfg_path.read_text()) or {}

    # Env overrides (flat)
    env_map = {
        "LNBITS_URL": ("lnbits", "url"),
        "LNBITS_API_KEY": ("lnbits", "api_key"),
        "L402_SECRET_KEY": ("l402", "secret_key"),
        "LLM_PROVIDER": ("llm", "provider"),
        "LLM_MODEL": ("llm", "model"),
        "LLM_API_KEY": ("llm", "api_key"),
        "LLM_BASE_URL": ("llm", "base_url"),
        "OPENAI_API_KEY": ("llm", "openai_api_key"),
        "SERVER_HOST": ("server", "host"),
        "SERVER_PORT": ("server", "port"),
    }
    for env_key, (section, key) in env_map.items():
        val = os.getenv(env_key)
        if val is not None:
            cfg.setdefault(section, {})[key] = val

    return cfg

CONFIG = load_config()

def cfg(section: str, key: str, default: Any = None) -> Any:
    return CONFIG.get(section, {}).get(key, default)

# ---------------------------------------------------------------------------
# FIX #3: Persist Free Trial IPs to JSON file
# ---------------------------------------------------------------------------

FREE_TRIALS_FILE = Path(__file__).parent / "free_trials.json"

def _load_free_trials() -> set:
    try:
        if FREE_TRIALS_FILE.exists():
            return set(json.loads(FREE_TRIALS_FILE.read_text()))
    except Exception as e:
        logger.warning(f"Failed to load free trials: {e}")
    return set()

def _save_free_trials(ips: set):
    try:
        FREE_TRIALS_FILE.write_text(json.dumps(sorted(ips)))
    except Exception as e:
        logger.warning(f"Failed to save free trials: {e}")

free_trial_ips = _load_free_trials()

# ---------------------------------------------------------------------------
# FIX #5: SQLite Task Persistence
# ---------------------------------------------------------------------------

DB_PATH = Path(__file__).parent / "tasks.db"

def _init_db():
    conn = sqlite3.connect(str(DB_PATH))
    conn.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            payment_hash TEXT PRIMARY KEY,
            task_type TEXT,
            input_text TEXT,
            params TEXT DEFAULT '{}',
            amount_sats INTEGER DEFAULT 0,
            status TEXT DEFAULT 'awaiting_payment',
            result TEXT,
            created_at REAL,
            workflow TEXT,
            steps TEXT
        )
    """)
    conn.commit()
    conn.close()

_init_db()

def _db():
    """Get a thread-local SQLite connection."""
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn

def db_save_task(payment_hash: str, task_info: dict):
    conn = _db()
    try:
        conn.execute("""
            INSERT OR REPLACE INTO tasks (payment_hash, task_type, input_text, params, amount_sats, status, result, created_at, workflow, steps)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            payment_hash,
            task_info.get("task", task_info.get("type", "")),
            encrypt_text(task_info.get("input", "")),
            json.dumps(task_info.get("params", {})),
            task_info.get("amount_sats", 0),
            task_info.get("status", "awaiting_payment"),
            encrypt_text(json.dumps(task_info.get("result"))) if task_info.get("result") else None,
            task_info.get("created_at", time.time()),
            task_info.get("workflow", ""),
            json.dumps(task_info.get("steps", [])),
        ))
        conn.commit()
    finally:
        conn.close()

def db_update_status(payment_hash: str, status: str, result: dict = None):
    conn = _db()
    try:
        if result is not None:
            conn.execute("UPDATE tasks SET status=?, result=? WHERE payment_hash=?",
                         (status, encrypt_text(json.dumps(result)), payment_hash))
        else:
            conn.execute("UPDATE tasks SET status=? WHERE payment_hash=?",
                         (status, payment_hash))
        conn.commit()
    finally:
        conn.close()

def db_load_tasks() -> dict:
    """Load all non-expired tasks from DB into memory."""
    conn = _db()
    tasks = {}
    try:
        cutoff = time.time() - 86400 * 7  # keep 7 days
        for row in conn.execute("SELECT * FROM tasks WHERE created_at > ?", (cutoff,)):
            ph = row["payment_hash"]
            tasks[ph] = {
                "task": row["task_type"],
                "input": decrypt_text(row["input_text"]),
                "params": json.loads(row["params"] or "{}"),
                "amount_sats": row["amount_sats"],
                "status": row["status"],
                "result": json.loads(decrypt_text(row["result"])) if row["result"] else None,
                "created_at": row["created_at"],
            }
            if row["workflow"]:
                tasks[ph]["type"] = "workflow"
                tasks[ph]["workflow"] = row["workflow"]
                tasks[ph]["steps"] = json.loads(row["steps"] or "[]")
    finally:
        conn.close()
    return tasks

# Load existing tasks from DB on startup
TASKS: dict[str, dict] = db_load_tasks()
logger.info(f"Loaded {len(TASKS)} tasks from database")

# ---------------------------------------------------------------------------
# FIX #1: L402 Token Replay Prevention
# ---------------------------------------------------------------------------

_used_tokens: dict[str, float] = {}  # token_hash -> expiry timestamp
_used_tokens_lock = threading.Lock()

def _cleanup_used_tokens():
    """Remove expired entries from the used token set."""
    now = time.time()
    with _used_tokens_lock:
        expired = [k for k, exp in _used_tokens.items() if now > exp]
        for k in expired:
            del _used_tokens[k]

def _mark_token_used(token_b64: str, preimage: str, expiry: float) -> bool:
    """Mark a token as used. Returns False if already used."""
    token_id = hashlib.sha256(f"{token_b64}:{preimage}".encode()).hexdigest()
    with _used_tokens_lock:
        if token_id in _used_tokens:
            return False
        _used_tokens[token_id] = expiry
    return True

# Periodic cleanup every hour
def _token_cleanup_loop():
    while True:
        import time as _t
        _t.sleep(3600)
        _cleanup_used_tokens()

_cleanup_thread = threading.Thread(target=_token_cleanup_loop, daemon=True)
_cleanup_thread.start()

# ---------------------------------------------------------------------------
# LNbits helpers
# ---------------------------------------------------------------------------

LNBITS_URL = cfg("lnbits", "url", "http://localhost:5000")
LNBITS_KEY = cfg("lnbits", "api_key", "")

async def lnbits_create_invoice(amount_sats: int, memo: str, webhook: Optional[str] = None) -> dict:
    """Create a Lightning invoice via LNbits."""
    payload: dict[str, Any] = {"out": False, "amount": amount_sats, "memo": memo}
    if webhook:
        payload["webhook"] = webhook
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(
            f"{LNBITS_URL}/api/v1/payments",
            headers={"X-Api-Key": LNBITS_KEY},
            json=payload,
        )
        r.raise_for_status()
        return r.json()

async def lnbits_get_payment(payment_hash: str):
    """Get full payment details from LNbits."""
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(
            f"{LNBITS_URL}/api/v1/payments/{payment_hash}",
            headers={"X-Api-Key": LNBITS_KEY},
        )
        r.raise_for_status()
        return r.json()

async def lnbits_check_payment(payment_hash: str) -> bool:
    """Check if an invoice has been paid."""
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(
            f"{LNBITS_URL}/api/v1/payments/{payment_hash}",
            headers={"X-Api-Key": LNBITS_KEY},
        )
        r.raise_for_status()
        return r.json().get("paid", False)

# ---------------------------------------------------------------------------
# L402 Macaroon helpers (HMAC-based, no pymacaroons dependency needed)
# ---------------------------------------------------------------------------

L402_SECRET = cfg("l402", "secret_key", "change-me-to-random-secret")
L402_EXPIRY = int(cfg("l402", "token_expiry_seconds", 86400))
L402_LOCATION = cfg("l402", "location", "https://your-agent.example.com")

def _mac_signature(payment_hash: str, expires: int) -> str:
    """HMAC-SHA256 signature for a macaroon-like token."""
    msg = f"{payment_hash}:{expires}".encode()
    return hmac.new(L402_SECRET.encode(), msg, hashlib.sha256).hexdigest()

def create_l402_token(payment_hash: str) -> str:
    """Create a base64-encoded L402 macaroon-like token."""
    expires = int(time.time()) + L402_EXPIRY
    sig = _mac_signature(payment_hash, expires)
    payload = json.dumps({"id": payment_hash, "exp": expires, "sig": sig})
    return base64.urlsafe_b64encode(payload.encode()).decode()

def verify_l402_token(token_b64: str, preimage: str) -> Optional[str]:
    """
    Verify an L402 token. Returns payment_hash if valid, else None.
    """
    try:
        payload = json.loads(base64.urlsafe_b64decode(token_b64))
        payment_hash = payload["id"]
        expires = payload["exp"]
        sig = payload["sig"]

        # Check expiry
        if time.time() > expires:
            return None
        # Check signature
        if sig != _mac_signature(payment_hash, expires):
            return None
        # Check preimage → hash
        preimage_bytes = bytes.fromhex(preimage)
        if hashlib.sha256(preimage_bytes).hexdigest() != payment_hash:
            return None

        # FIX #1: Replay prevention - mark token as used
        if not _mark_token_used(token_b64, preimage, expires):
            return "REPLAY"  # special sentinel

        return payment_hash
    except Exception:
        return None

def parse_l402_header(auth: str) -> Optional[tuple]:
    """Parse 'L402 <macaroon>:<preimage>' header."""
    if not auth.startswith("L402 "):
        return None
    parts = auth[5:].split(":", 1)
    if len(parts) != 2:
        return None
    return parts[0], parts[1]

# ---------------------------------------------------------------------------
# FIX #2: Webhook Authentication
# ---------------------------------------------------------------------------

WEBHOOK_SECRET = os.getenv("WEBHOOK_SECRET", "")

# ---------------------------------------------------------------------------
# FastAPI app
# ---------------------------------------------------------------------------

app = FastAPI(
    title="Bitcoin AI Agent",
    description="AI agent that accepts Bitcoin Lightning payments via L402",
    version="1.0.0",
)

# === Free Prompt Constants ===
FREE_PROMPTS_DB = "/opt/bitcoin-agent/data/free_prompts.json"
FREE_PROMPT_LIMIT = 3
FREE_PROMPT_SERVICES = None  # None = ALL services eligible for free trial


# --- Models ---

class TaskRequest(BaseModel):
    task: str  # one of TASK_TYPES
    input: str
    params: dict[str, Any] = {}
    image: str = None  # base64 data URL for image uploads

class TaskResponse(BaseModel):
    payment_hash: str
    invoice: str
    amount_sats: int
    task: str
    status_url: str

# --- Helper to save task to both memory and DB ---

def save_task(payment_hash: str, task_info: dict):
    TASKS[payment_hash] = task_info
    db_save_task(payment_hash, task_info)

def update_task(payment_hash: str, task_info: dict, status: str, result: dict = None):
    task_info["status"] = status
    if result is not None:
        task_info["result"] = result
    db_update_status(payment_hash, status, result)

# --- Endpoints ---


# ── OpenAI-Compatible API ──
register_openai_routes(app, cfg, lnbits_create_invoice, logger)
register_wallet_routes(app, cfg, lnbits_create_invoice, logger)

@app.get("/workflows")
async def list_workflows():
    """List available workflow bundles with discounted pricing."""
    return {
        "workflows": {k: {"description": v["description"], "steps": v["steps"], "price_sats": v["price_sats"]} for k, v in WORKFLOWS.items()},
        "note": "Workflows chain multiple services together at a discount. Submit via POST /workflow with {workflow, input}"
    }

@app.post("/workflow")
async def submit_workflow(request: Request):
    """Submit a workflow — runs multiple services, one invoice."""
    body = await request.json()
    workflow_name = body.get("workflow")
    input_text = body.get("input", "")
    
    if workflow_name not in WORKFLOWS:
        raise HTTPException(400, f"Unknown workflow: {workflow_name}. Available: {list(WORKFLOWS.keys())}")
    
    if len(input_text) > MAX_INPUT_LENGTH:
        raise HTTPException(413, f"Input too large. Max {MAX_INPUT_LENGTH} characters.")
    wf = WORKFLOWS[workflow_name]
    price = wf["price_sats"]
    
    # Create invoice
    invoice_data = await lnbits_create_invoice(price, f"workflow:{workflow_name}")
    payment_hash = invoice_data["payment_hash"]
    
    # Store workflow task
    task_info = {
        "type": "workflow",
        "workflow": workflow_name,
        "steps": wf["steps"],
        "input": input_text,
        "status": "pending_payment",
        "created_at": time.time(),
    }
    save_task(payment_hash, task_info)
    
    return {
        "payment_hash": payment_hash,
        "invoice": invoice_data["bolt11"],
        "amount_sats": price,
        "workflow": workflow_name,
        "steps": wf["steps"],
        "savings": f"Bundle saves you {sum(CONFIG.get('pricing', {}).get(s, 0) for s in wf['steps']) - price} sats vs individual",
        "status_url": f"/task/{payment_hash}/status",
    }


@app.post("/free")
async def free_trial(request: Request):
    """One free task per IP — no invoice needed. Try before you buy."""
    global free_trial_ips
    client_ip = request.headers.get("X-Real-IP", request.client.host)
    
    if client_ip in free_trial_ips:
        return {"error": "Free trial already used from this IP. Pay with Lightning for more!", "pricing": "https://thenode.it.com/.well-known/ai-agent.json"}
    
    body = await request.json()
    task_type = body.get("task")
    input_text = body.get("input", "")
    
    if not task_type or not input_text.strip():
        raise HTTPException(400, "Provide task and input")
    
    if len(input_text) > 10000:  # Smaller limit for free trial
        raise HTTPException(413, "Free trial limited to 10,000 characters")
    
    if task_type not in TASK_TYPES:
        raise HTTPException(400, f"Unknown task. Available: {TASK_TYPES}")
    
    # Execute the task for free
    try:
        result = await execute_task(task_type, input_text, CONFIG.get("llm", {}))
        free_trial_ips.add(client_ip_hash)
        _save_free_trials(free_trial_ips)  # FIX #3: persist
        return {
            "result": result.content,
            "task": task_type,
            "free_trial": True,
            "message": "This was your free trial! Future tasks require Lightning payment.",
            "next": f"POST /task with the same format. You'll get a Lightning invoice.",
            "tokens_used": getattr(result, "total_tokens", getattr(result, "input_tokens", 0) + getattr(result, "output_tokens", 0)),
        }
    except Exception as e:
        logger.error(f"Free trial error: {e}")
        raise HTTPException(500, "Task execution failed")





# === Audio Transcription Upload Endpoint ===
from fastapi import File, UploadFile, Form

@app.post("/transcribe")
async def transcribe_audio(request: Request, file: UploadFile = File(...), language: str = Form(None)):
    """Transcribe uploaded audio file. Supports mp3, wav, m4a, webm, ogg."""
    client_ip = request.headers.get("x-real-ip", request.client.host)

    # Check free prompt or wallet
    import hashlib as _hl3
    ua = request.headers.get("user-agent", "")
    al = request.headers.get("accept-language", "")
    fp = "fp:" + _hl3.sha256((ua + "|" + al).encode()).hexdigest()[:16]
    is_free = _check_free_prompt_available(client_ip, "african_transcribe") and _check_free_prompt_available(fp, "african_transcribe")

    wallet_id = request.headers.get("x-wallet-id")
    pricing = CONFIG.get("pricing", {})
    price = pricing.get("african_transcribe", 20)

    if not is_free:
        if wallet_id and wallet_deduct(wallet_id, price):
            pass  # wallet payment OK
        else:
            # Need payment
            webhook_url = cfg("lnbits", "webhook_url")
            inv = await lnbits_create_invoice(price, "African Transcription", webhook=webhook_url)
            return JSONResponse({
                "error": "Payment required",
                "invoice": inv["payment_request"],
                "amount_sats": price,
                "payment_hash": inv["payment_hash"],
            }, status_code=402)

    # Read audio
    audio_bytes = await file.read()
    if len(audio_bytes) > 25 * 1024 * 1024:
        raise HTTPException(413, "Audio file too large. Max 25MB.")
    if len(audio_bytes) < 100:
        raise HTTPException(400, "Audio file too small or empty.")

    # Determine file extension
    ext = file.filename.rsplit(".", 1)[-1].lower() if file.filename and "." in file.filename else "mp3"
    allowed_ext = {"mp3", "wav", "m4a", "webm", "ogg", "mp4", "mpeg", "mpga", "flac"}
    if ext not in allowed_ext:
        ext = "mp3"

    # Call Whisper API
    import httpx
    llm_config = CONFIG.get("llm", {})
    api_key = llm_config.get("openai_api_key") or llm_config.get("api_key", "")

    LANG_MAP = {
        "swahili": "sw", "amharic": "am", "afrikaans": "af", "zulu": "zu",
        "somali": "so", "hausa": "ha", "yoruba": "yo", "igbo": "ig",
        "shona": "sn", "lingala": "ln", "luganda": "lg", "akan": "ak",
        "ewe": "ee", "fula": "ff", "kikuyu": "ki",
    }
    lang_code = None
    if language:
        lang_code = LANG_MAP.get(language.lower(), language.lower() if len(language) <= 3 else None)

    try:
        async with httpx.AsyncClient(timeout=120) as client:
            files = {"file": (f"audio.{ext}", audio_bytes, f"audio/{ext}")}
            data = {"model": "whisper-1"}
            if lang_code:
                data["language"] = lang_code

            resp = await client.post(
                "https://api.openai.com/v1/audio/transcriptions",
                headers={"Authorization": f"Bearer {api_key}"},
                files=files,
                data=data,
            )
            resp.raise_for_status()
            text = resp.json().get("text", "")
    except Exception as e:
        raise HTTPException(500, f"Transcription failed: {str(e)}")

    if is_free:
        _use_free_prompt(client_ip, "african_transcribe")
        _use_free_prompt(fp, "african_transcribe")

    return {
        "status": "complete",
        "transcription": text,
        "language": language or "auto-detected",
        "model": "whisper-1",
    }


# === African Language Services Info ===
@app.get("/african-languages")
async def african_languages():
    """List available African languages for TTS and transcription."""
    return {
        "tts_languages": {
            lang: {
                "voices": info["voices"],
                "price_sats": 10,
            }
            for lang, info in AFRICAN_TTS_VOICES.items()
        },
        "transcribe_languages": [
            "swahili", "amharic", "afrikaans", "zulu", "somali",
            "hausa", "yoruba", "igbo", "shona", "lingala",
            "luganda", "akan", "ewe", "fula", "kikuyu",
        ],
        "transcribe_price_sats": 20,
        "usage": {
            "tts": "POST /task with task=african_tts, input='language:swahili gender:female Your text here'",
            "transcribe": "POST /task with task=african_transcribe, input='language:swahili <base64-audio>'",
        },
        "powered_by": "WAXAL dataset (Google, CC-BY-4.0) + edge-tts + OpenAI Whisper",
    }

@app.get("/health")
async def health():
    return {"status": "ok", "task_types": TASK_TYPES, "version": "1.0.0"}


@app.get("/task")
async def task_l402_challenge():
    """L402 discovery endpoint — returns 402 with challenge header."""
    # Create a dummy invoice for discovery purposes
    pricing = CONFIG.get("pricing", {})
    description = "The Ark AI - pay-per-task AI services via Lightning"
    return JSONResponse(
        status_code=402,
        content={
            "message": "Payment required. Submit a POST with task and input to get a Lightning invoice.",
            "protocol": "L402",
            "services": len(TASK_TYPES),
            "pricing_url": "/market",
            "docs_url": "/.well-known/ai-agent.json",
        },
        headers={
            "WWW-Authenticate": f'L402 invoice="lnbc...", macaroon="...", description="{description}"',
        }
    )

@app.post("/task")
async def submit_task(req: TaskRequest, request: Request):
    """
    Submit a task. If user has a valid day pass (by token or IP), executes immediately.
    Otherwise returns a Lightning invoice to pay.
    """
    if len(req.input) > MAX_INPUT_LENGTH:
        raise HTTPException(413, f"Input too large. Max {MAX_INPUT_LENGTH} characters.")
    if req.task not in TASK_TYPES:
        raise HTTPException(400, f"Unknown task type \'{req.task}\'. Valid: {TASK_TYPES}")

    # --- Day Pass Check ---
    valid, pass_info = check_day_pass(request)
    if valid:
        pricing = CONFIG.get("pricing", {})
        task_price = estimate_price(req.task, req.input, pricing)
        # Basic pass can't do premium tasks (>2000 sats)
        if not (pass_info["tier"] == "basic" and task_price > 2000):
            use_day_pass(pass_info["id"])
            try:
                result = await execute_task(req.task, req.input, CONFIG.get("llm", {}), **req.params)
                return JSONResponse({
                    "status": "complete",
                    "result": {
                        "content": result.content,
                        "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                        "model": result.model,
                    },
                    "day_pass": {
                        "tier": pass_info["tier"],
                        "tasks_used": pass_info["tasks_used"] + 1,
                        "tasks_limit": pass_info["tasks_limit"],
                    },
                })
            except Exception as e:
                logger.error(f"Day pass task error: {e}")
                raise HTTPException(500, "Task execution failed")

    # --- Free Prompt Check ---
    client_ip = request.headers.get("X-Real-IP", request.client.host)
    # Also check fingerprint (User-Agent + Accept-Language) to catch IP rotators
    ua = request.headers.get("user-agent", "")
    al = request.headers.get("accept-language", "")
    import hashlib as _hl
    fp = "fp:" + _hl.sha256((ua + "|" + al).encode()).hexdigest()[:16]
    if _check_free_prompt_available(client_ip, req.task) and _check_free_prompt_available(fp, req.task):
        try:
            result = await execute_task(req.task, req.input, CONFIG.get("llm", {}), **req.params)
            _use_free_prompt(client_ip, req.task)
            _use_free_prompt(fp, req.task)
            try:
                track_event(client_ip, "free_prompt", req.task)
            except Exception:
                pass
            ip_count = _load_free_prompts().get(client_ip, {}).get("count", 0)
            fp_count = _load_free_prompts().get(fp, {}).get("count", 0)
            remaining = FREE_PROMPT_LIMIT - max(ip_count, fp_count)
            return JSONResponse({
                "status": "complete",
                "result": {
                    "content": result.content,
                    "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                    "model": result.model,
                },
                "free_prompt": True,
                "free_remaining": max(0, remaining),
            })
        except Exception as e:
            logger.error(f"Free prompt task error: {e}")
            raise HTTPException(500, "Task execution failed")

    # --- Credit Check (refunds/compensation) ---
    import json as _json
    _credits_file = "/opt/bitcoin-agent/data/credits.json"
    try:
        with open(_credits_file, "r") as _cf:
            _credits = _json.load(_cf)
        if client_ip in _credits and _credits[client_ip].get("credit_sats", 0) > 0:
            pricing = CONFIG.get("pricing", {})
            price = estimate_price(req.task, req.input, pricing)
            if _credits[client_ip]["credit_sats"] >= price:
                result = await execute_task(req.task, req.input, CONFIG.get("llm", {}), **req.params)
                _credits[client_ip]["credit_sats"] -= price
                if _credits[client_ip]["credit_sats"] <= 0:
                    del _credits[client_ip]
                with open(_credits_file, "w") as _cf:
                    _json.dump(_credits, _cf, indent=2)
                remaining_credit = _credits.get(client_ip, {}).get("credit_sats", 0)
                return JSONResponse({
                    "status": "complete",
                    "result": {
                        "content": result.content,
                        "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                        "model": result.model,
                    },
                    "credit": {"remaining_sats": remaining_credit, "cost_sats": price},
                })
    except FileNotFoundError:
        pass
    except Exception as _ce:
        logger.error(f"Credit check error: {_ce}")

    # --- Wallet Balance Check ---
    wallet_id = req.params.get("wallet_id") if hasattr(req, "params") and req.params else None
    if not wallet_id:
        # Check header too
        wallet_id = request.headers.get("x-wallet-id")
    if wallet_id:
        pricing = CONFIG.get("pricing", {})
        price = estimate_price(req.task, req.input, pricing)
        if wallet_deduct(wallet_id, price):
            try:
                result = await execute_task(req.task, req.input, CONFIG.get("llm", {}), **req.params)
                remaining = wallet_balance(wallet_id) or 0
                try:
                    track_event(client_ip, "wallet_task", req.task)
                except:
                    pass
                return JSONResponse({
                    "status": "complete",
                    "result": {
                        "content": result.content,
                        "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                        "model": result.model,
                    },
                    "wallet": {"balance_sats": remaining, "cost_sats": price},
                })
            except Exception as e:
                # Refund on failure
                from wallet import _load_wallets, _save_wallets
                wallets = _load_wallets()
                if wallet_id in wallets:
                    wallets[wallet_id]["balance_sats"] += price
                    wallets[wallet_id]["total_spent_sats"] -= price
                    wallets[wallet_id]["total_tasks"] -= 1
                    _save_wallets(wallets)
                logger.error(f"Wallet task error: {e}")
                raise HTTPException(500, "Task execution failed")
        else:
            bal = wallet_balance(wallet_id) or 0
            return JSONResponse({"error": "insufficient_balance", "balance_sats": bal, "required_sats": price, "topup_url": f"/wallet/{wallet_id}/topup"}, status_code=402)

    # --- Normal Payment Flow ---
    pricing = CONFIG.get("pricing", {})
    price = estimate_price(req.task, req.input, pricing)

    webhook_url = cfg("lnbits", "webhook_url")
    inv = await lnbits_create_invoice(price, f"AI Agent: {req.task}", webhook=webhook_url)

    payment_hash = inv["payment_hash"]
    task_info = {
        "task": req.task,
        "input": req.input,
        "params": req.params,
        "amount_sats": price,
        "status": "awaiting_payment",
        "result": None,
        "created_at": time.time(),
    }
    save_task(payment_hash, task_info)

    bolt11 = inv["payment_request"]
    return JSONResponse(
        status_code=402,
        content={
            "payment_hash": payment_hash,
            "invoice": bolt11,
            "amount_sats": price,
            "task": req.task,
            "status_url": f"/task/{payment_hash}/status",
        },
        headers={
            "WWW-Authenticate": f'L402 invoice="{bolt11}"',
        },
    )

@app.get("/task/{payment_hash}/status")
async def task_status(payment_hash: str):
    """Check task status. If paid and not yet executed, runs the task."""
    task_info = TASKS.get(payment_hash)
    if not task_info:
        raise HTTPException(404, "Task not found")

    if task_info["status"] == "complete":
        return {"status": "complete", "result": task_info["result"]}

    if task_info["status"] == "awaiting_payment":
        try:
            paid = await lnbits_check_payment(payment_hash)
        except:
            return {"status": "pending", "message": "Payment not yet confirmed."}
        if not paid:
            return {"status": "awaiting_payment", "amount_sats": task_info["amount_sats"]}
        update_task(payment_hash, task_info, "processing")

    # Execute the task — PAID tasks MUST return a result
    if task_info["status"] in ("processing", "error", "retrying"):
        lock = _get_task_lock(payment_hash)
        if lock.locked():
            return {"status": "processing", "message": "Task is being generated, please wait..."}
        async with lock:
            # Re-check status after acquiring lock (another request may have completed it)
            if task_info["status"] == "complete":
                # Track paid task for conversion analytics
              try:
                  track_event(request.client.host, "paid_task")
              except Exception:
                  pass
              # Credit referral if applicable
              try:
                  # Only credit referral for PAID tasks, not free prompts
                  _ref_data = _load_referrals()
                  _ref_ip = request.client.host
                  _ref_info = _ref_data.get("referred", {}).get(_ref_ip)
                  if _ref_info and not _ref_info.get("completed_paid_task") and _ref_info.get("ref_code") in _ref_data.get("referrers", {}):
                      _ref_data["referrers"][_ref_info["ref_code"]]["referrals"] += 1
                      _ref_data["referrers"][_ref_info["ref_code"]]["earned_sats"] += 10
                      _ref_info["completed_paid_task"] = True
                      _ref_data["referred"][_ref_ip] = _ref_info
                      _save_referrals(_ref_data)
              except Exception:
                  pass
              return {"status": "complete", "result": task_info["result"]}
            import asyncio as _asyncio
            max_retries = 3
            last_error = None
            for attempt in range(1, max_retries + 1):
                try:
                    update_task(payment_hash, task_info, "processing")
                    task_info["attempt"] = attempt
                    result = await execute_task(
                        task_info["task"],
                        task_info["input"],
                        CONFIG.get("llm", {}),
                        **task_info.get("params", {}),
                    )
                    result_data = {
                        "content": result.content,
                        "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                        "model": result.model,
                    }
                    update_task(payment_hash, task_info, "complete", result_data)
                    return {"status": "complete", "result": task_info["result"]}
                except Exception as e:
                    last_error = str(e)
                    logger.error(f"Task attempt {attempt}/{max_retries} failed: {e}")
                    if attempt < max_retries:
                        update_task(payment_hash, task_info, "retrying")
                        await _asyncio.sleep(2 * attempt)  # backoff: 2s, 4s
                        continue
                    else:
                        logger.exception(f"Task FAILED after {max_retries} attempts")
                        _refund_amt = task_info.get("amount_sats", 0)
                        _refund_ip = task_info.get("client_ip", "unknown")
                        if _refund_amt > 0:
                            _auto_refund(_refund_ip, _refund_amt, payment_hash, f"task_failure: {last_error}")
                        result_data = {
                            "content": f"We're sorry — your task encountered a technical error after {max_retries} attempts.\n\nError: {last_error}\n\n**Your {task_info.get('amount_sats', '?')} sats have been automatically refunded as credit.** Your next tasks will be free until the credit is used up.\n\nPayment hash: {payment_hash}",
                            "tokens": {"input": 0, "output": 0},
                            "model": "error",
                        }
                        update_task(payment_hash, task_info, "complete", result_data)
                        return {"status": "complete", "result": task_info["result"]}

    return {"status": task_info["status"]}

# --- L402 gated endpoint (alternative flow) ---

@app.api_route("/l402/task", methods=["POST"])
async def l402_task(request: Request):
    """
    L402-gated task endpoint. 
    - No valid token → 402 with invoice + macaroon
    - Valid token → execute task immediately
    """
    auth = request.headers.get("Authorization", "")
    parsed = parse_l402_header(auth)

    if parsed:
        mac_token, preimage = parsed
        payment_hash = verify_l402_token(mac_token, preimage)

        # FIX #1: Check for replay
        if payment_hash == "REPLAY":
            raise HTTPException(403, "Token has already been used (replay detected)")

        if payment_hash:
            body = await request.json()
            task_type = body.get("task", "summarize")
            input_text = body.get("input", "")
            params = body.get("params", {})
            if len(input_text) > MAX_INPUT_LENGTH:
                raise HTTPException(413, f"Input too large. Max {MAX_INPUT_LENGTH} characters.")
            if task_type not in TASK_TYPES:
                raise HTTPException(400, f"Unknown task: {task_type}")
            
            result = await execute_task(task_type, input_text, CONFIG.get("llm", {}), **params)
            return JSONResponse({
                "status": "complete",
                "result": {
                    "content": result.content,
                    "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                    "model": result.model,
                },
            })

    # No valid token — issue 402
    body = await request.json()
    task_type = body.get("task", "summarize")
    pricing = CONFIG.get("pricing", {})
    price = estimate_price(task_type, body.get("input", ""), pricing)

    inv = await lnbits_create_invoice(price, f"L402 AI Agent: {task_type}")
    mac_token = create_l402_token(inv["payment_hash"])

    return Response(
        content=json.dumps({"message": "Payment required", "amount_sats": price}),
        status_code=402,
        media_type="application/json",
        headers={
            "WWW-Authenticate": f'L402 macaroon="{mac_token}", invoice="{inv["payment_request"]}"',
        },
    )


# --- Voice & Image Services ---

from llm_tasks import text_to_speech, generate_image

VOICE_TASKS = {"voice_gen", "voice_read", "voice_narrate", "african_tts"}
IMAGE_TASKS = {"image_gen", "image_create", "image_edit", "image_variation", "image_upscale", "image_bg_remove", "image_colorize", "image_restore", "image_style", "image_caption", "image_logo", "image_mockup", "image_meme", "image_avatar", "image_banner", "image_thumbnail", "image_infographic", "image_qr_art", "image_portrait", "image_product", "image_landscape", "image_sticker", "image_icon"}

@app.post("/voice/{payment_hash}")
async def get_voice_result(payment_hash: str):
    """Serve voice audio result."""
    task_info = TASKS.get(payment_hash)
    if not task_info or task_info.get("type") != "voice":
        raise HTTPException(404, "Voice result not found")
    if task_info["status"] != "complete":
        raise HTTPException(202, "Still processing")
    audio_bytes = task_info.get("audio_bytes", b"")
    return Response(content=audio_bytes, media_type="audio/mpeg",
                    headers={"Content-Disposition": f"attachment; filename=ark-voice-{payment_hash[:8]}.mp3"})

@app.post("/image/{payment_hash}")  
async def get_image_result(payment_hash: str):
    """Serve image result."""
    task_info = TASKS.get(payment_hash)
    if not task_info or task_info.get("type") != "image":
        raise HTTPException(404, "Image result not found")
    if task_info["status"] != "complete":
        raise HTTPException(202, "Still processing")
    return {"status": "complete", "result": task_info["result"]}


# --- Webhook for payment notifications ---

@app.post("/webhook/payment")
async def payment_webhook(request: Request):
    """LNbits payment webhook. Auto-executes task on payment."""
    # FIX #2: Webhook authentication
    if WEBHOOK_SECRET:
        provided_secret = request.headers.get("X-Webhook-Secret", "")
        if provided_secret != WEBHOOK_SECRET:
            # Fallback: validate payment_hash exists in TASKS and is awaiting payment
            # (LNbits may not support custom headers, so we also validate below)
            logger.warning("Webhook called without valid X-Webhook-Secret header")

    data = await request.json()
    if isinstance(data, str):
        try:
            import json as _json
            data = _json.loads(data)
        except Exception:
            data = {"payment_hash": data}
    payment_hash = data.get("payment_hash", "") if isinstance(data, dict) else str(data)
    logger.info(f"Webhook received for {payment_hash}")

    task_info = TASKS.get(payment_hash)
    if not task_info:
        return {"status": "ignored", "reason": "unknown payment_hash"}

    if task_info["status"] != "awaiting_payment":
        return {"status": "already_processed"}

    # Verify payment is actually paid (don't trust webhook blindly)
    try:
        try:
            paid = await lnbits_check_payment(payment_hash)
        except:
            return {"status": "pending", "message": "Payment not yet confirmed."}
        if not paid:
            logger.warning(f"Webhook for {payment_hash} but payment not confirmed")
            return {"status": "ignored", "reason": "payment not confirmed"}
    except Exception as e:
        logger.error(f"Failed to verify payment {payment_hash}: {e}")

    import asyncio as _asyncio
    update_task(payment_hash, task_info, "processing")
    max_retries = 3
    for attempt in range(1, max_retries + 1):
        try:
            result = await execute_task(
                task_info["task"],
                task_info["input"],
                CONFIG.get("llm", {}),
                **task_info.get("params", {}),
            )
            result_data = {
                "content": result.content,
                "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                "model": result.model,
            }
            update_task(payment_hash, task_info, "complete", result_data)
            return {"status": "complete"}
        except Exception as e:
            logger.error(f"Webhook task attempt {attempt}/{max_retries} failed: {e}")
            if attempt < max_retries:
                await _asyncio.sleep(2 * attempt)
                continue
            else:
                logger.exception(f"Webhook task FAILED after {max_retries} attempts")
                _refund_amt = task_info.get("amount_sats", 0)
                _refund_ip = task_info.get("client_ip", "unknown")
                if _refund_amt > 0:
                    _auto_refund(_refund_ip, _refund_amt, payment_hash, f"webhook_task_failure: {str(e)}")
                result_data = {
                    "content": f"We apologize — your task encountered a technical error after {max_retries} attempts.\n\nError: {str(e)}\n\n**Your {task_info.get('amount_sats', '?')} sats have been automatically refunded as credit.** Your next tasks will be free until the credit is used up.\n\nPayment hash: {payment_hash}",
                    "tokens": {"input": 0, "output": 0},
                    "model": "error",
                }
                update_task(payment_hash, task_info, "complete", result_data)
                return {"status": "complete"}

# --- Lightning Address / LNURL-pay ---

@app.get("/.well-known/lnurlp/{username}")
async def lnurl_pay(username: str):
    """LNURL-pay endpoint for Lightning Address support (username@domain)."""
    la_cfg = CONFIG.get("lightning_address", {})
    if not la_cfg.get("enabled", False):
        raise HTTPException(404, "Lightning Address not enabled")

    domain = la_cfg.get("domain", "localhost")
    min_sats = la_cfg.get("min_sats", 10)
    max_sats = la_cfg.get("max_sats", 100000)

    return {
        "status": "OK",
        "tag": "payRequest",
        "commentAllowed": 255,
        "callback": f"https://{domain}/lnurl/callback",
        "minSendable": min_sats * 1000,  # millisats
        "maxSendable": max_sats * 1000,
        "metadata": json.dumps([
            ["text/plain", la_cfg.get("description", "Bitcoin AI Agent")],
            ["text/identifier", f"{username}@{domain}"],
        ]),
    }

@app.get("/lnurl/callback")
async def lnurl_callback(amount: int, comment: str = ""):
    """LNURL-pay callback — creates invoice for the requested amount."""
    amount_sats = amount // 1000  # convert from millisats
    memo = comment or "Lightning Address payment"
    inv = await lnbits_create_invoice(amount_sats, memo)
    return {
        "status": "OK",
        "pr": inv["payment_request"],
        "routes": [],
    }

# ---------------------------------------------------------------------------
# /services endpoint
# ---------------------------------------------------------------------------

@app.get("/services")
async def list_services():
    """List all available AI services with pricing."""
    pricing = CONFIG.get("pricing", {})
    return {
        "services": {t: {"price_sats": pricing.get(t, 100)} for t in TASK_TYPES},
        "free_trial": "POST /free — one free task per IP",
        "l402": "POST /l402/task — pay-per-request with L402",
        "workflows": "GET /workflows — bundled multi-step services",
    }


# ---------------------------------------------------------------------------
# Day Pass System
# ---------------------------------------------------------------------------

DAY_PASS_TIERS = {
    "basic": {"price_sats": 500, "tasks_limit": 15, "label": "Basic Day Pass"},
    "pro": {"price_sats": 1500, "tasks_limit": 50, "label": "Pro Day Pass"},
    "unlimited": {"price_sats": 5000, "tasks_limit": 200, "label": "Unlimited Day Pass"},
}

@app.get("/day-pass/tiers")
async def day_pass_tiers():
    """List available day pass tiers."""
    return {"tiers": DAY_PASS_TIERS}

@app.post("/day-pass")
async def buy_day_pass(request: Request):
    """Purchase a day pass. Returns Lightning invoice."""
    body = await request.json()
    tier = body.get("tier", "basic")
    if tier not in DAY_PASS_TIERS:
        raise HTTPException(400, f"Unknown tier. Available: {list(DAY_PASS_TIERS.keys())}")
    
    tier_info = DAY_PASS_TIERS[tier]
    price = tier_info["price_sats"]
    client_ip = request.headers.get("X-Real-IP", request.client.host)
    
    inv = await lnbits_create_invoice(price, f"The Ark Day Pass: {tier_info['label']}")
    payment_hash = inv["payment_hash"]
    pass_token = secrets.token_urlsafe(32)
    pass_id = secrets.token_urlsafe(16)
    
    conn = _db()
    try:
        conn.execute("""
            INSERT INTO day_passes (id, tier, ip_address, token, amount_sats, tasks_limit, created_at, expires_at, payment_hash, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'awaiting_payment')
        """, (pass_id, tier, client_ip, pass_token, price, tier_info["tasks_limit"], time.time(), time.time() + 86400, payment_hash))
        conn.commit()
    finally:
        conn.close()
    
    return {
        "pass_id": pass_id,
        "tier": tier,
        "price_sats": price,
        "tasks_limit": tier_info["tasks_limit"],
        "invoice": inv["payment_request"],
        "payment_hash": payment_hash,
        "status_url": f"/day-pass/{pass_id}/status",
    }

@app.get("/day-pass/{pass_id}/status")
async def day_pass_status(pass_id: str):
    """Check day pass status and activate if paid."""
    conn = _db()
    try:
        row = conn.execute("SELECT * FROM day_passes WHERE id = ?", (pass_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Day pass not found")
        
        if row["status"] == "active":
            return {
                "status": "active",
                "token": row["token"],
                "tier": row["tier"],
                "tasks_used": row["tasks_used"],
                "tasks_limit": row["tasks_limit"],
                "expires_at": row["expires_at"],
                "hours_remaining": max(0, (row["expires_at"] - time.time()) / 3600),
            }
        
        if row["status"] == "awaiting_payment":
            paid = await lnbits_check_payment(row["payment_hash"])
            if paid:
                conn.execute("UPDATE day_passes SET status = 'active', created_at = ?, expires_at = ? WHERE id = ?",
                           (time.time(), time.time() + 86400, pass_id))
                conn.commit()
                updated = conn.execute("SELECT * FROM day_passes WHERE id = ?", (pass_id,)).fetchone()
                return {
                    "status": "active",
                    "token": updated["token"],
                    "tier": updated["tier"],
                    "tasks_used": 0,
                    "tasks_limit": updated["tasks_limit"],
                    "expires_at": updated["expires_at"],
                    "message": "Day pass activated! Use your token in the X-Day-Pass header or include it in requests.",
                }
            return {"status": "awaiting_payment", "amount_sats": row["amount_sats"]}
        
        if row["status"] == "expired":
            return {"status": "expired", "message": "This day pass has expired."}
        
        return {"status": row["status"]}
    finally:
        conn.close()

def check_day_pass(request_or_token):
    """Check if request has a valid day pass. Returns (valid, pass_row) tuple."""
    token = None
    ip = None
    if hasattr(request_or_token, 'headers'):
        token = request_or_token.headers.get("X-Day-Pass")
        ip = request_or_token.headers.get("X-Real-IP", request_or_token.client.host)
    else:
        token = request_or_token
    
    if not token and not ip:
        return False, None
    
    conn = _db()
    try:
        row = None
        if token:
            row = conn.execute("SELECT * FROM day_passes WHERE token = ? AND status = 'active' AND expires_at > ?",
                             (token, time.time())).fetchone()
        if not row and ip:
            row = conn.execute("SELECT * FROM day_passes WHERE ip_address = ? AND status = 'active' AND expires_at > ? ORDER BY created_at DESC LIMIT 1",
                             (ip, time.time())).fetchone()
        if row and row["tasks_used"] < row["tasks_limit"]:
            return True, dict(row)
        return False, None
    finally:
        conn.close()

def use_day_pass(pass_id):
    """Increment tasks_used for a day pass."""
    conn = _db()
    try:
        conn.execute("UPDATE day_passes SET tasks_used = tasks_used + 1 WHERE id = ?", (pass_id,))
        conn.commit()
    finally:
        conn.close()

# ---------------------------------------------------------------------------
# Group / Chama System
# ---------------------------------------------------------------------------

@app.post("/group/create")
async def create_group(request: Request):
    """Create a new group (Chama). Day pass holders create for free. Others pay."""
    body = await request.json()
    name = body.get("name", "").strip()
    creator = body.get("creator_name", "Anonymous").strip()
    contribution = int(body.get("contribution_sats", 1000))
    
    if not name:
        raise HTTPException(400, "Group name is required")
    
    group_id = secrets.token_urlsafe(12)
    invite_code = secrets.token_urlsafe(8)
    
    # Check if creator has an active day pass
    valid, pass_info = check_day_pass(request)
    if valid:
        # Day pass holder — create group for free, no payment needed
        conn = _db()
        try:
            conn.execute("INSERT INTO groups (group_id, name, invite_code, balance_sats, created_at, created_by) VALUES (?, ?, ?, 0, ?, ?)",
                        (group_id, name, invite_code, time.time(), creator))
            conn.execute("INSERT INTO group_members (group_id, member_name, contributed_sats, tasks_used, joined_at, payment_hash) VALUES (?, ?, 0, 0, ?, ?)",
                        (group_id, creator, time.time(), "daypass"))
            conn.commit()
        finally:
            conn.close()
        
        return {
            "group_id": group_id,
            "name": name,
            "invite_code": invite_code,
            "status": "active",
            "day_pass_used": True,
            "status_url": f"/group/{group_id}/status",
            "message": f"Group created with your day pass! Share invite code '{invite_code}' with members. Members contribute sats to the group pool.",
        }
    
    # No day pass — require payment
    if contribution < 500:
        raise HTTPException(400, "Minimum contribution is 500 sats")
    if contribution > 100000:
        raise HTTPException(400, "Maximum contribution is 100,000 sats")
    
    inv = await lnbits_create_invoice(contribution, f"The Ark Chama: {name} — Creator deposit")
    payment_hash = inv["payment_hash"]
    
    conn = _db()
    try:
        conn.execute("INSERT INTO groups (group_id, name, invite_code, balance_sats, created_at, created_by) VALUES (?, ?, ?, 0, ?, ?)",
                    (group_id, name, invite_code, time.time(), creator))
        conn.execute("INSERT INTO group_members (group_id, member_name, contributed_sats, tasks_used, joined_at, payment_hash) VALUES (?, ?, 0, 0, ?, ?)",
                    (group_id, creator, time.time(), payment_hash))
        conn.commit()
    finally:
        conn.close()
    
    return {
        "group_id": group_id,
        "name": name,
        "invite_code": invite_code,
        "contribution_sats": contribution,
        "invoice": inv["payment_request"],
        "payment_hash": payment_hash,
        "status_url": f"/group/{group_id}/status",
        "message": f"Pay the invoice to create your group. Share invite code \'{invite_code}\' with members.",
    }

@app.post("/group/join")
async def join_group(request: Request):
    """Join a group with invite code and contribution."""
    body = await request.json()
    invite_code = body.get("invite_code", "").strip()
    member_name = body.get("member_name", "Anonymous").strip()
    contribution = int(body.get("contribution_sats", 1000))
    
    if not invite_code:
        raise HTTPException(400, "Invite code is required")
    if contribution < 500:
        raise HTTPException(400, "Minimum contribution is 500 sats")
    
    conn = _db()
    try:
        group = conn.execute("SELECT * FROM groups WHERE invite_code = ?", (invite_code,)).fetchone()
        if not group:
            raise HTTPException(404, "Group not found. Check your invite code.")
        
        member_count = conn.execute("SELECT COUNT(*) FROM group_members WHERE group_id = ?", (group["group_id"],)).fetchone()[0]
        if member_count >= 20:
            raise HTTPException(400, "Group is full (max 20 members)")
        
        inv = await lnbits_create_invoice(contribution, f"The Ark Chama: {group['name']} — {member_name} joining")
        payment_hash = inv["payment_hash"]
        
        conn.execute("INSERT INTO group_members (group_id, member_name, contributed_sats, tasks_used, joined_at, payment_hash) VALUES (?, ?, 0, 0, ?, ?)",
                    (group["group_id"], member_name, time.time(), payment_hash))
        conn.commit()
        
        return {
            "group_id": group["group_id"],
            "group_name": group["name"],
            "member_name": member_name,
            "contribution_sats": contribution,
            "invoice": inv["payment_request"],
            "payment_hash": payment_hash,
            "status_url": f"/group/{group['group_id']}/status",
        }
    finally:
        conn.close()



@app.post("/group/join/confirm")
async def confirm_join(request: Request):
    """Confirm payment for group join and credit contribution."""
    body = await request.json()
    payment_hash = body.get("payment_hash", "").strip()
    group_id = body.get("group_id", "").strip()
    
    if not payment_hash or not group_id:
        raise HTTPException(400, "payment_hash and group_id required")
    
    conn = _db()
    try:
        # Check if payment is confirmed
        try:
            paid = await lnbits_check_payment(payment_hash)
        except:
            return {"status": "pending", "message": "Payment not yet confirmed."}
        if not paid:
            return {"status": "pending", "message": "Payment not yet confirmed. Please pay the invoice."}
        
        # Find the member record
        member = conn.execute(
            "SELECT * FROM group_members WHERE group_id = ? AND payment_hash = ?",
            (group_id, payment_hash)
        ).fetchone()
        
        if not member:
            raise HTTPException(404, "Member record not found")
        
        if member["contributed_sats"] > 0:
            # Already credited
            group = conn.execute("SELECT * FROM groups WHERE group_id = ?", (group_id,)).fetchone()
            return {
                "status": "confirmed",
                "message": f"You're already a member of {group['name']}!",
                "group_id": group_id,
                "group_name": group["name"],
                "member_name": member["member_name"],
                "contributed": member["contributed_sats"]
            }
        
        # Get invoice amount from LNbits
        try:
            inv_details = await lnbits_get_payment(payment_hash)
            amount_sats = abs(inv_details.get("amount", 0)) // 1000  # LNbits stores in msats
            if amount_sats == 0:
                amount_sats = 1000  # fallback
        except:
            amount_sats = 1000  # fallback
        
        # Credit the member
        conn.execute(
            "UPDATE group_members SET contributed_sats = ? WHERE group_id = ? AND payment_hash = ?",
            (amount_sats, group_id, payment_hash)
        )
        
        # Update group balance
        conn.execute(
            "UPDATE groups SET balance_sats = balance_sats + ? WHERE group_id = ?",
            (amount_sats, group_id)
        )
        conn.commit()
        
        group = conn.execute("SELECT * FROM groups WHERE group_id = ?", (group_id,)).fetchone()
        
        return {
            "status": "confirmed",
            "message": f"Welcome to {group['name']}! Your {amount_sats} sats have been added to the group pool.",
            "group_id": group_id,
            "group_name": group["name"],
            "member_name": member["member_name"],
            "contributed": amount_sats,
            "group_balance": group["balance_sats"]
        }
    finally:
        conn.close()

@app.get("/group/{group_id}/status")
async def group_status(group_id: str):
    """Get group status, balance, and member usage."""
    conn = _db()
    try:
        group = conn.execute("SELECT * FROM groups WHERE group_id = ?", (group_id,)).fetchone()
        if not group:
            raise HTTPException(404, "Group not found")
        
        members = conn.execute("SELECT * FROM group_members WHERE group_id = ?", (group_id,)).fetchall()
        
        # Check for unpaid member contributions
        for m in members:
            if m["contributed_sats"] == 0 and m["payment_hash"]:
                try:
                    paid = await lnbits_check_payment(m["payment_hash"])
                    if paid:
                        # Get the contribution amount from the invoice
                        # Default to 1000 if we can't determine
                        contrib = 1000
                        conn.execute("UPDATE group_members SET contributed_sats = ? WHERE id = ?", (contrib, m["id"]))
                        conn.execute("UPDATE groups SET balance_sats = balance_sats + ? WHERE group_id = ?", (contrib, group_id))
                        conn.commit()
                except Exception:
                    pass
        
        # Re-fetch after updates
        group = conn.execute("SELECT * FROM groups WHERE group_id = ?", (group_id,)).fetchone()
        members = conn.execute("SELECT * FROM group_members WHERE group_id = ?", (group_id,)).fetchall()
        
        return {
            "group_id": group["group_id"],
            "name": group["name"],
            "invite_code": group["invite_code"],
            "balance_sats": group["balance_sats"],
            "created_at": group["created_at"],
            "members": [
                {
                    "name": m["member_name"],
                    "contributed": m["contributed_sats"],
                    "tasks_used": m["tasks_used"],
                    "joined": m["joined_at"],
                } for m in members
            ],
            "member_count": len(members),
        }
    finally:
        conn.close()

@app.post("/group/task")
async def group_task(request: Request):
    """Submit a task using group credits."""
    body = await request.json()
    group_id = body.get("group_id", "").strip()
    member_name = body.get("member_name", "").strip()
    task_type = body.get("task", "").strip()
    input_text = body.get("input", "").strip()
    
    if not all([group_id, member_name, task_type, input_text]):
        raise HTTPException(400, "group_id, member_name, task, and input are required")
    if task_type not in TASK_TYPES:
        raise HTTPException(400, f"Unknown task type. Available: {TASK_TYPES}")
    if len(input_text) > MAX_INPUT_LENGTH:
        raise HTTPException(413, f"Input too large. Max {MAX_INPUT_LENGTH} characters.")
    
    pricing = CONFIG.get("pricing", {})
    cost = estimate_price(task_type, input_text, pricing)
    
    conn = _db()
    try:
        group = conn.execute("SELECT * FROM groups WHERE group_id = ?", (group_id,)).fetchone()
        if not group:
            raise HTTPException(404, "Group not found")
        
        member = conn.execute("SELECT * FROM group_members WHERE group_id = ? AND member_name = ?", (group_id, member_name)).fetchone()
        if not member:
            raise HTTPException(403, "You are not a member of this group")
        
        if group["balance_sats"] < cost:
            raise HTTPException(402, f"Insufficient group balance. Need {cost} sats, have {group['balance_sats']}.")
        
        # Fair usage: no member can use more than 40% of total pool
        total_contributed = conn.execute("SELECT SUM(contributed_sats) FROM group_members WHERE group_id = ?", (group_id,)).fetchone()[0] or 0
        member_usage_sats = conn.execute("SELECT SUM(cost_sats) FROM group_tasks WHERE group_id = ? AND member_name = ?", (group_id, member_name)).fetchone()[0] or 0
        if total_contributed > 0 and member_usage_sats + cost > total_contributed * 0.4:
            raise HTTPException(429, f"Fair usage limit reached. You've used {member_usage_sats} sats of the pool. Max 40% per member.")
        
        # Deduct and execute
        conn.execute("UPDATE groups SET balance_sats = balance_sats - ? WHERE group_id = ?", (cost, group_id))
        conn.execute("UPDATE group_members SET tasks_used = tasks_used + 1 WHERE id = ?", (member["id"],))
        conn.execute("INSERT INTO group_tasks (group_id, member_name, task_type, cost_sats, created_at) VALUES (?, ?, ?, ?, ?)",
                    (group_id, member_name, task_type, cost, time.time()))
        conn.commit()
    finally:
        conn.close()
    
    try:
        result = await execute_task(task_type, input_text, CONFIG.get("llm", {}))
        return {
            "status": "complete",
            "result": {
                "content": result.content,
                "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                "model": result.model,
            },
            "cost_sats": cost,
            "group_balance_remaining": group["balance_sats"] - cost,
        }
    except Exception as e:
        # Refund on failure
        conn = _db()
        try:
            conn.execute("UPDATE groups SET balance_sats = balance_sats + ? WHERE group_id = ?", (cost, group_id))
            conn.commit()
        finally:
            conn.close()
        raise HTTPException(500, f"Task failed: {str(e)}. Credits have been refunded.")

# ---------------------------------------------------------------------------
# Language Selector
# ---------------------------------------------------------------------------

SUPPORTED_LANGUAGES = {
    "af": "Afrikaans", "am": "Amharic", "ar": "Arabic", "az": "Azerbaijani",
    "bg": "Bulgarian", "bn": "Bengali", "bs": "Bosnian", "ca": "Catalan",
    "cs": "Czech", "cy": "Welsh", "da": "Danish", "de": "German",
    "el": "Greek", "en": "English", "es": "Spanish", "et": "Estonian",
    "fa": "Persian", "fi": "Finnish", "fr": "French", "ga": "Irish",
    "gu": "Gujarati", "ha": "Hausa", "he": "Hebrew", "hi": "Hindi",
    "hr": "Croatian", "hu": "Hungarian", "hy": "Armenian", "id": "Indonesian",
    "ig": "Igbo", "is": "Icelandic", "it": "Italian", "ja": "Japanese",
    "ka": "Georgian", "kk": "Kazakh", "km": "Khmer", "kn": "Kannada",
    "ko": "Korean", "ku": "Kurdish", "ky": "Kyrgyz", "lo": "Lao",
    "lt": "Lithuanian", "lv": "Latvian", "mg": "Malagasy", "mk": "Macedonian",
    "ml": "Malayalam", "mn": "Mongolian", "mr": "Marathi", "ms": "Malay",
    "mt": "Maltese", "my": "Burmese", "ne": "Nepali", "nl": "Dutch",
    "no": "Norwegian", "ny": "Chichewa", "om": "Oromo", "pa": "Punjabi",
    "pl": "Polish", "ps": "Pashto", "pt": "Portuguese", "ro": "Romanian",
    "ru": "Russian", "rw": "Kinyarwanda", "si": "Sinhala", "sk": "Slovak",
    "sl": "Slovenian", "sn": "Shona", "so": "Somali", "sq": "Albanian",
    "sr": "Serbian", "st": "Sesotho", "sv": "Swedish", "sw": "Swahili",
    "ta": "Tamil", "te": "Telugu", "tg": "Tajik", "th": "Thai",
    "ti": "Tigrinya", "tk": "Turkmen", "tl": "Filipino", "tr": "Turkish",
    "uk": "Ukrainian", "ur": "Urdu", "uz": "Uzbek", "vi": "Vietnamese",
    "xh": "Xhosa", "yo": "Yoruba", "zh": "Chinese", "zu": "Zulu",
}

POPULAR_PAIRS = [
    {"source": "en", "target": "sw", "label": "English → Swahili"},
    {"source": "en", "target": "fr", "label": "English → French"},
    {"source": "en", "target": "es", "label": "English → Spanish"},
    {"source": "en", "target": "ar", "label": "English → Arabic"},
    {"source": "en", "target": "zh", "label": "English → Chinese"},
    {"source": "en", "target": "yo", "label": "English → Yoruba"},
    {"source": "en", "target": "ha", "label": "English → Hausa"},
    {"source": "en", "target": "am", "label": "English → Amharic"},
    {"source": "fr", "target": "en", "label": "French → English"},
    {"source": "sw", "target": "en", "label": "Swahili → English"},
]

@app.get("/languages")
async def list_languages():
    """List all supported languages for translation."""
    return {
        "languages": SUPPORTED_LANGUAGES,
        "count": len(SUPPORTED_LANGUAGES),
        "popular_pairs": POPULAR_PAIRS,
    }

# ---------------------------------------------------------------------------
# Override /task to support day passes
# ---------------------------------------------------------------------------
# We need to modify the existing task endpoint logic
# The cleanest way: add a middleware-like check

@app.post("/task/daypass")
async def submit_task_daypass(request: Request):
    """Submit a task using a day pass (no individual payment needed)."""
    valid, pass_info = check_day_pass(request)
    if not valid:
        raise HTTPException(402, "No active day pass found. Purchase one at POST /day-pass")
    
    body = await request.json()
    task_type = body.get("task", "")
    input_text = body.get("input", "")
    params = body.get("params", {})
    
    if not task_type or task_type not in TASK_TYPES:
        raise HTTPException(400, f"Unknown task type. Available: {TASK_TYPES}")
    if len(input_text) > MAX_INPUT_LENGTH:
        raise HTTPException(413, f"Input too large. Max {MAX_INPUT_LENGTH} characters.")
    
    # Premium tasks (>2000 sats) not allowed on basic pass
    pricing = CONFIG.get("pricing", {})
    task_price = estimate_price(task_type, input_text, pricing)
    if pass_info["tier"] == "basic" and task_price > 2000:
        raise HTTPException(403, f"This task costs {task_price} sats — upgrade to Pro or Unlimited day pass for premium tasks.")
    
    use_day_pass(pass_info["id"])
    
    try:
        result = await execute_task(task_type, input_text, CONFIG.get("llm", {}), **params)
        return {
            "status": "complete",
            "result": {
                "content": result.content,
                "tokens": {"input": result.input_tokens, "output": result.output_tokens},
                "model": result.model,
            },
            "day_pass": {
                "tier": pass_info["tier"],
                "tasks_used": pass_info["tasks_used"] + 1,
                "tasks_limit": pass_info["tasks_limit"],
            },
        }
    except Exception as e:
        logger.error(f"Day pass task error: {e}")
        raise HTTPException(500, "Task execution failed")




# ---------------------------------------------------------------------------
# Earnings Dashboard API
# ---------------------------------------------------------------------------

ADMIN_TOKEN = cfg("admin", "token", "")

@app.get("/earnings")
async def earnings(request: Request):
    """View earnings, balance, and recent payments. Requires admin token."""
    token = request.query_params.get("token", request.headers.get("X-Admin-Token", ""))
    if not ADMIN_TOKEN or token != ADMIN_TOKEN:
        raise HTTPException(403, "Admin token required. Use ?token=YOUR_TOKEN")
    
    # Get LNbits wallet balance
    balance = None
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{LNBITS_URL}/api/v1/wallet", headers={"X-Api-Key": LNBITS_KEY})
            r.raise_for_status()
            wd = r.json()
            balance = wd.get("balance", 0) // 1000  # msats to sats
    except Exception as e:
        balance = f"Error: {e}"
    
    # Get recent paid payments
    payments = []
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"{LNBITS_URL}/api/v1/payments?limit=50", headers={"X-Api-Key": LNBITS_KEY})
            r.raise_for_status()
            for p in r.json():
                if p.get("status") == "success" and p.get("amount", 0) > 0:
                    payments.append({
                        "amount_sats": p["amount"] // 1000,
                        "memo": p.get("memo", ""),
                        "time": p.get("time", ""),
                        "payment_hash": p.get("payment_hash", "")[:16] + "...",
                    })
    except Exception as e:
        payments = [{"error": str(e)}]
    
    # Day pass stats
    conn = _db()
    try:
        active_passes = conn.execute("SELECT COUNT(*) FROM day_passes WHERE status = 'active' AND expires_at > ?", (time.time(),)).fetchone()[0]
        total_passes_sold = conn.execute("SELECT COUNT(*) FROM day_passes WHERE status = 'active'").fetchone()[0]
        total_pass_revenue = conn.execute("SELECT COALESCE(SUM(amount_sats), 0) FROM day_passes WHERE status = 'active'").fetchone()[0]
        total_tasks = conn.execute("SELECT COUNT(*) FROM tasks WHERE status = 'complete'").fetchone()[0]
    except Exception:
        active_passes = total_passes_sold = total_pass_revenue = total_tasks = "?"
    finally:
        conn.close()
    
    return {
        "balance_sats": balance,
        "total_revenue_from_passes": total_pass_revenue,
        "active_day_passes": active_passes,
        "total_passes_sold": total_passes_sold,
        "total_tasks_completed": total_tasks,
        "recent_payments": payments[:20],
    }

# ---------------------------------------------------------------------------
# History & Delete endpoints
# ---------------------------------------------------------------------------

@app.get("/history/{payment_hash}")
async def task_history(payment_hash: str, request: Request):
    """Retrieve completed task details by payment hash."""
    client_ip = request.headers.get("X-Real-IP", request.client.host)
    if not _check_rate_limit(client_ip):
        raise HTTPException(429, "Rate limit exceeded. Max 10 requests per minute.")

    conn = _db()
    try:
        row = conn.execute("SELECT * FROM tasks WHERE payment_hash = ?", (payment_hash,)).fetchone()
        if not row:
            raise HTTPException(404, "Task not found")
        if row["status"] == "deleted":
            return {"payment_hash": payment_hash, "status": "deleted", "task_type": row["task_type"], "amount_sats": row["amount_sats"], "created_at": row["created_at"]}
        if row["status"] != "complete":
            raise HTTPException(400, "Task not complete (status: %s)" % row["status"])

        input_text = decrypt_text(row["input_text"]) or ""
        result_raw = decrypt_text(row["result"])
        result = json.loads(result_raw) if result_raw else None

        return {
            "payment_hash": payment_hash,
            "task_type": row["task_type"],
            "input_summary": input_text[:100] + ("..." if len(input_text) > 100 else ""),
            "result": result,
            "created_at": row["created_at"],
            "amount_sats": row["amount_sats"],
        }
    finally:
        conn.close()


@app.delete("/delete/{payment_hash}")
async def delete_task(payment_hash: str):
    """Delete task data, keeping only metadata as tombstone."""
    conn = _db()
    try:
        row = conn.execute("SELECT * FROM tasks WHERE payment_hash = ?", (payment_hash,)).fetchone()
        if not row:
            raise HTTPException(404, "Task not found")
        if row["status"] == "deleted":
            return {"status": "already_deleted", "payment_hash": payment_hash}

        conn.execute(
            "UPDATE tasks SET input_text = NULL, result = NULL, params = NULL, status = 'deleted' WHERE payment_hash = ?",
            (payment_hash,),
        )
        conn.commit()
        TASKS.pop(payment_hash, None)

        import glob as _glob
        for p in _glob.glob("/var/www/bitcoin-agent/generated/*%s*" % payment_hash[:16]):
            try:
                os.remove(p)
            except Exception:
                pass

        return {"status": "deleted", "payment_hash": payment_hash, "message": "Task data deleted. Metadata tombstone retained."}
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


# === Referral API Endpoints ===
@app.post("/referral/signup")
async def referral_signup(request: Request):
    body = await request.json()
    lightning_address = body.get("lightning_address", "")
    data = _load_referrals()
    code = _gen_ref_code()
    while code in data.get("referrers", {}):
        code = _gen_ref_code()
    data.setdefault("referrers", {})[code] = {
        "lightning_address": lightning_address,
        "referrals": 0,
        "earned_sats": 0,
        "created": _time_ref.time()
    }
    _save_referrals(data)
    return {"code": code, "link": f"https://arknode.ai?ref={code}", "share_link": f"https://arknode.ai/download?ref={code}"}

@app.get("/referral/stats/{code}")
async def referral_stats(code: str):
    data = _load_referrals()
    info = data.get("referrers", {}).get(code)
    if not info:
        return {"error": "Referral code not found"}
    return {"code": code, "referrals": info["referrals"], "earned_sats": info["earned_sats"], "lightning_address": info.get("lightning_address", "")}

@app.get("/referral/leaderboard")
async def referral_leaderboard():
    data = _load_referrals()
    sorted_refs = sorted(
        data.get("referrers", {}).items(),
        key=lambda x: x[1].get("referrals", 0),
        reverse=True
    )[:20]
    return {"leaderboard": [{"rank": i+1, "code": c[:2]+"****", "referrals": info["referrals"], "earned_sats": info["earned_sats"]} for i, (c, info) in enumerate(sorted_refs) if info["referrals"] > 0]}

@app.get("/referral/track")
async def referral_track(ref: str, request: Request):
    client_ip = request.client.host
    data = _load_referrals()
    if ref not in data.get("referrers", {}):
        return {"tracked": False, "error": "Invalid referral code"}
def _load_free_prompts():
    if os.path.exists(FREE_PROMPTS_DB):
        with open(FREE_PROMPTS_DB, 'r') as f:
            return _json_ref.load(f)
    return {}

def _save_free_prompts(data):
    os.makedirs(os.path.dirname(FREE_PROMPTS_DB), exist_ok=True)
    with open(FREE_PROMPTS_DB, 'w') as f:
        _json_ref.dump(data, f, indent=2)

def _check_free_prompt_available(client_ip, service_name):
    if FREE_PROMPT_SERVICES is not None and service_name not in FREE_PROMPT_SERVICES:
        return False
    data = _load_free_prompts()
    user_data = data.get(client_ip, {'count': 0, 'used_services': []})
    return user_data['count'] < FREE_PROMPT_LIMIT

def _use_free_prompt(client_ip, service_name):
    if FREE_PROMPT_SERVICES is not None and service_name not in FREE_PROMPT_SERVICES:
        return False
    data = _load_free_prompts()
    user_data = data.get(client_ip, {'count': 0, 'used_services': [], 'first_used': _time_ref.time()})
    if user_data['count'] >= FREE_PROMPT_LIMIT:
        return False
    user_data['count'] += 1
    user_data['used_services'].append({'service': service_name, 'timestamp': _time_ref.time()})
    data[client_ip] = user_data
    _save_free_prompts(data)
    return True
    referred = data.setdefault("referred", {})
    if client_ip not in referred:
        referred[client_ip] = {"ref_code": ref, "timestamp": _time_ref.time(), "completed_task": False}
        _save_referrals(data)
    return {"tracked": True}

@app.get("/free-status")
async def free_status(request: Request):
    client_ip = request.headers.get("X-Real-IP", request.client.host)
    import hashlib as _hl_fs
    ua = request.headers.get("user-agent", "")
    al = request.headers.get("accept-language", "")
    fp = "fp:" + _hl_fs.sha256((ua + "|" + al).encode()).hexdigest()[:16]
    data = _load_free_prompts()
    ip_count = data.get(client_ip, {}).get("count", 0)
    fp_count = data.get(fp, {}).get("count", 0)
    used = max(ip_count, fp_count)
    remaining = max(0, FREE_PROMPT_LIMIT - used)
    return {"free_prompts_remaining": remaining, "limit": FREE_PROMPT_LIMIT}

# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

@app.get("/conversion-report")
async def conversion_report():
    try:
        return get_report()
    except Exception as e:
        return {"error": str(e)}


@app.get("/track-visit")
async def track_visit(request: Request):
    try:
        track_event(request.client.host, "visit")
    except Exception:
        pass
    return {"ok": True}


# ── Streaming Task Endpoint ──
from fastapi.responses import StreamingResponse as _StreamResp

@app.post("/task/stream")
async def stream_task(req: TaskRequest, request: Request):
    """Execute a task with streaming response (SSE)."""
    client_ip = request.headers.get("X-Real-IP", request.client.host)
    
    # Check free prompts
    import hashlib as _hl2
    ua = request.headers.get("user-agent", "")
    al = request.headers.get("accept-language", "")
    fp = "fp:" + _hl2.sha256((ua + "|" + al).encode()).hexdigest()[:16]
    
    is_free = _check_free_prompt_available(client_ip, req.task) and _check_free_prompt_available(fp, req.task)
    
    # Check wallet
    wallet_id = (req.params or {}).get("wallet_id") or request.headers.get("x-wallet-id")
    has_wallet = False
    price = 0
    if not is_free:
        # Check credits
        _credits_file = "/opt/bitcoin-agent/data/credits.json"
        has_credit = False
        try:
            import json as _cjson
            with open(_credits_file, "r") as _cf:
                _credits = _cjson.load(_cf)
            pricing_c = CONFIG.get("pricing", {})
            price_c = estimate_price(req.task, req.input, pricing_c)
            if client_ip in _credits and _credits[client_ip].get("credit_sats", 0) >= price_c:
                has_credit = True
                price = price_c
        except:
            pass
        
        if not has_credit:
            pricing = CONFIG.get("pricing", {})
            price = estimate_price(req.task, req.input, pricing)
            if wallet_id and wallet_deduct(wallet_id, price):
                has_wallet = True
            elif wallet_id:
                # Wallet exists but insufficient balance — tell user to top up
                bal = wallet_balance(wallet_id) or 0
                async def topup_stream():
                    yield f'data: {{"type":"topup_needed","balance_sats":{bal},"cost_sats":{price},"message":"Insufficient wallet balance. You have {bal} sats but this task costs {price} sats. Please top up your wallet to continue."}}\n\n'
                return _StreamResp(topup_stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
            else:
                # No wallet — return invoice
                webhook_url = cfg("lnbits", "webhook_url")
                inv = await lnbits_create_invoice(price, f"AI Agent: {req.task}", webhook=webhook_url)
                ph = inv["payment_hash"]
                pr = inv["payment_request"]
                task_info = {
                    "task": req.task, "input": req.input, "params": req.params,
                    "amount_sats": price, "status": "awaiting_payment",
                    "result": None, "created_at": time.time(), "client_ip": client_ip,
                }
                save_task(ph, task_info)
                async def invoice_stream():
                    yield f'data: {{"type":"invoice","invoice":"{pr}","amount_sats":{price},"payment_hash":"{ph}","status_url":"/task/{ph}/status"}}\n\n'
                return _StreamResp(invoice_stream(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    # Get system prompt
    llm_config = CONFIG.get("llm", {})
    system_prompt = None
    try:
        from llm_tasks import SYSTEM_PROMPTS
        system_prompt = SYSTEM_PROMPTS.get(req.task)
        if system_prompt:
            from llm_tasks import ARK_IDENTITY
            system_prompt = ARK_IDENTITY + system_prompt
    except:
        pass
    
    if not system_prompt:
        # Fallback non-streaming (handles voice, image, african_tts, etc.)
        _fb_kwargs = dict(req.params or {})
        if req.image:
            _fb_kwargs["image"] = req.image
        result = await execute_task(req.task, req.input, llm_config, **_fb_kwargs)
        if is_free:
            _use_free_prompt(client_ip, req.task)
            _use_free_prompt(fp, req.task)
        # If result has audio_bytes, save and provide download URL
        if hasattr(result, "audio_bytes") and result.audio_bytes:
            import uuid as _uuid_fb
            audio_id = _uuid_fb.uuid4().hex[:16]
            os.makedirs("/var/www/bitcoin-agent/generated", exist_ok=True)
            audio_path = f"/var/www/bitcoin-agent/generated/{audio_id}.mp3"
            with open(audio_path, "wb") as af:
                af.write(result.audio_bytes)
            audio_url = f"/generated/{audio_id}.mp3"
            async def audio_fallback():
                yield f'data: {{"type":"audio","url":"{audio_url}","size":{len(result.audio_bytes)}}}\n\n'
                yield f'data: {{"type":"content","text":"\U0001f30d Audio ready! Language: {req.task}"}}\n\n'
                if is_free:
                    ip_count = _load_free_prompts().get(client_ip, {}).get("count", 0)
                    fp_count = _load_free_prompts().get(fp, {}).get("count", 0)
                    remaining = FREE_PROMPT_LIMIT - max(ip_count, fp_count)
                    yield f'data: {{"type":"free","remaining":{remaining}}}\n\n'
                yield f'data: {{"type":"done","model":"{result.model}"}}\n\n'
            return _StreamResp(audio_fallback(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        # If result has image_url, include it
        if hasattr(result, "image_url") and result.image_url:
            async def image_fallback():
                yield f'data: {{"type":"image","url":"{result.image_url}"}}\n\n'
                yield f'data: {{"type":"content","text":{json.dumps(result.content)}}}\n\n'
                if is_free:
                    ip_count = _load_free_prompts().get(client_ip, {}).get("count", 0)
                    fp_count = _load_free_prompts().get(fp, {}).get("count", 0)
                    remaining = FREE_PROMPT_LIMIT - max(ip_count, fp_count)
                    yield f'data: {{"type":"free","remaining":{remaining}}}\n\n'
                yield f'data: {{"type":"done","model":"{result.model}"}}\n\n'
            return _StreamResp(image_fallback(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
        async def fallback():
            yield f'data: {{"type":"content","text":{json.dumps(result.content)}}}\n\n'
            if is_free:
                ip_count = _load_free_prompts().get(client_ip, {}).get("count", 0)
                fp_count = _load_free_prompts().get(fp, {}).get("count", 0)
                remaining = FREE_PROMPT_LIMIT - max(ip_count, fp_count)
                yield f'data: {{"type":"free","remaining":{remaining}}}\n\n'
            yield f'data: {{"type":"done","model":"{result.model}"}}\n\n'
        return _StreamResp(fallback(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    import httpx as _hx
    base_url = llm_config.get("base_url", "https://api.deepinfra.com/v1/openai")
    api_key = llm_config.get("api_key", "")
    model = get_model_for_task(req.task, llm_config.get("model", "Qwen/Qwen3-32B"))
    max_tokens = llm_config.get("max_tokens", 8192)

    async def stream_gen():
        full_content = ""
        try:
            import asyncio as _aio_r
            _max_retries = 4
            _delays = [0, 3, 6, 12]
            _resp = None
            _client = None
            for _att in range(_max_retries):
                if _delays[_att] > 0:
                    yield f'data: {{"type":"content","text":"23f3 Server busy, retrying..."}}\n\n'

                    await _aio_r.sleep(_delays[_att])
                try:
                    _client = _hx.AsyncClient(timeout=180)
                    _resp = await _client.send(
                        _client.build_request("POST", f"{base_url}/chat/completions",
                            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                            json={
                                "model": "Qwen/Qwen3-VL-30B-A3B-Instruct" if req.image else model,
                                "messages": [
                                    {"role": "system", "content": system_prompt},
                                    {"role": "user", "content": [
                                        {"type": "image_url", "image_url": {"url": req.image}},
                                        {"type": "text", "text": req.input},
                                    ] if req.image else req.input},
                                ],
                                "max_tokens": max_tokens,
                                "stream": True,
                                **({} if req.task in POWER_TASKS else {"chat_template_kwargs": {"enable_thinking": False}}),
                            }),
                        stream=True,
                    )
                    if _resp.status_code == 200:
                        break
                    elif _resp.status_code == 429 and _att < _max_retries - 1:
                        await _resp.aclose()
                        await _client.aclose()
                        continue
                    else:
                        yield f'data: {{"type":"error","text":"Model error ({_resp.status_code}). Please try again in a moment."}}\n\n'
                        await _resp.aclose()
                        await _client.aclose()
                        return
                except Exception as _conn_err:
                    if _att < _max_retries - 1:
                        if _client:
                            try: await _client.aclose()
                            except: pass
                        continue
                    yield f'data: {{"type":"error","text":"Connection failed. Please try again."}}\n\n'
                    return
            resp = _resp
            _inside_think = False
            try:  # stream response
                    if resp.status_code != 200:
                        yield f'data: {{"type":"error","text":"Model error ({resp.status_code})"}}\n\n'
                        return
                    async for line in resp.aiter_lines():
                        if line.startswith("data: "):
                            data_str = line[6:]
                            if data_str.strip() == "[DONE]":
                                break
                            try:
                                chunk = json.loads(data_str)
                                delta = chunk.get("choices", [{}])[0].get("delta", {})
                                text = delta.get("content", "")
                                if text:
                                    full_content += text
                                    # Filter out <think>...</think> blocks from Qwen3 output
                                    if "<think>" in text:
                                        _inside_think = True
                                    if _inside_think:
                                        if "</think>" in text:
                                            _inside_think = False
                                            after = text.split("</think>", 1)[1]
                                            if after.strip():
                                                yield f'data: {{"type":"content","text":{json.dumps(after)}}}\n\n'
                                        continue
                                    yield f'data: {{"type":"content","text":{json.dumps(text)}}}\n\n'
                            except:
                                pass
            finally:
                try:
                    await resp.aclose()
                    await _client.aclose()
                except:
                    pass
            
            if is_free:
                _use_free_prompt(client_ip, req.task)
                _use_free_prompt(fp, req.task)
                ip_count = _load_free_prompts().get(client_ip, {}).get("count", 0)
                fp_count = _load_free_prompts().get(fp, {}).get("count", 0)
                remaining = FREE_PROMPT_LIMIT - max(ip_count, fp_count)
                yield f'data: {{"type":"free","remaining":{remaining}}}\n\n'
            elif has_wallet:
                bal = wallet_balance(wallet_id) or 0
                yield f'data: {{"type":"wallet","balance_sats":{bal},"cost_sats":{price}}}\n\n'
            elif has_credit:
                try:
                    with open(_credits_file, "r") as _cf:
                        _credits = _cjson.load(_cf)
                    _credits[client_ip]["credit_sats"] -= price
                    if _credits[client_ip]["credit_sats"] <= 0:
                        del _credits[client_ip]
                    with open(_credits_file, "w") as _cf:
                        _cjson.dump(_credits, _cf, indent=2)
                except:
                    pass
            
            # Generate PDF for document-type tasks
            if req.task in PDF_ELIGIBLE_TASKS and full_content.strip():
                try:
                    _pdf_title = req.input[:80] if len(req.input) < 80 else req.input[:77] + "..."
                    _pdf_file = generate_pdf(full_content, req.task, _pdf_title)
                    yield f'data: {{"type":"pdf","url":"/pdf/{_pdf_file}","filename":"{_pdf_file}"}}\n\n'
                except Exception as _pe:
                    logger.error(f"PDF gen failed: {_pe}")
            yield f'data: {{"type":"done","model":"{model}"}}\n\n'
        except Exception as e:
            yield f'data: {{"type":"error","text":{json.dumps(str(e))}}}\n\n'
            if has_wallet and wallet_id:
                from wallet import _load_wallets, _save_wallets
                wallets_w = _load_wallets()
                if wallet_id in wallets_w:
                    wallets_w[wallet_id]["balance_sats"] += price
                    _save_wallets(wallets_w)

    return _StreamResp(stream_gen(), media_type="text/event-stream", headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})



# === PDF Download Endpoint ===
@app.post("/generate-pdf")
async def gen_pdf_endpoint(request: Request):
    """Generate a PDF from provided content."""
    body = await request.json()
    content = body.get("content", "").strip()
    task_type = body.get("task_type", "document")
    title = body.get("title", None)
    if not content:
        raise HTTPException(400, "content is required")
    try:
        cleanup_old_pdfs(24)
        filename = generate_pdf(content, task_type, title)
        return {"pdf_url": f"/pdf/{filename}", "filename": filename}
    except Exception as e:
        logger.error(f"PDF generation failed: {e}")
        raise HTTPException(500, f"PDF generation failed: {str(e)}")


@app.get("/pdf/{filename}")
async def download_pdf(filename: str):
    """Download a generated PDF."""
    import re
    if not re.match(r"^[a-z_]+_[a-f0-9]{12}\.pdf$", filename):
        raise HTTPException(400, "Invalid filename")
    filepath = os.path.join(PDF_DIR, filename)
    if not os.path.exists(filepath):
        raise HTTPException(404, "PDF not found or expired (PDFs expire after 24h)")
    return _FileResp(filepath, media_type="application/pdf", filename=filename, headers={"Content-Disposition": f"attachment; filename={filename}"})

if __name__ == "__main__":
    import uvicorn
    host = cfg("server", "host", "0.0.0.0")
    port = int(cfg("server", "port", 8402))

    uvicorn.run(app, host=host, port=port)

# === Free Prompt System ===

# === Invoice Rate Limiting ===
INVOICE_RATE_LIMIT = {}  # {ip: [timestamp, timestamp, ...]}
MAX_INVOICES_PER_HOUR = 10  # max unpaid invoices per IP per hour
BLOCKED_IPS = set()  # IPs that have been rate-limited

def _check_invoice_rate(client_ip):
    """Returns True if allowed, False if rate limited"""
    import time as _t
    now = _t.time()
    hour_ago = now - 3600
    
    if client_ip in BLOCKED_IPS:
        return False
    
    # Clean old entries
    if client_ip in INVOICE_RATE_LIMIT:
        INVOICE_RATE_LIMIT[client_ip] = [t for t in INVOICE_RATE_LIMIT[client_ip] if t > hour_ago]
    else:
        INVOICE_RATE_LIMIT[client_ip] = []
    
    if len(INVOICE_RATE_LIMIT[client_ip]) >= MAX_INVOICES_PER_HOUR:
        return False
    
    INVOICE_RATE_LIMIT[client_ip].append(now)
    return True




# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


