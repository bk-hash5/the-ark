"""
Workflow chains — multi-step automated pipelines.
This is what free ChatGPT CANNOT do.
"""

WORKFLOWS = {
    "full_code_audit": {
        "description": "Complete code audit: review + security scan + unit tests",
        "steps": ["code_review", "security_scan", "unit_test"],
        "price_sats": 120,  # discount vs buying separately (150)
    },
    "launch_pack": {
        "description": "Everything for a product launch: landing page copy + SEO meta + social posts + ad copy",
        "steps": ["content_write", "seo_meta", "social_post", "ad_copy"],
        "price_sats": 150,  # vs 170 separately
    },
    "startup_kit": {
        "description": "Startup starter: pitch deck + privacy policy + terms of service",
        "steps": ["pitch_deck", "privacy_policy", "terms_gen"],
        "price_sats": 500,  # vs 700 separately
    },
    "code_ship": {
        "description": "Ship-ready code: review + docs + unit tests + changelog + Dockerfile",
        "steps": ["code_review", "doc_gen", "unit_test", "changelog_gen", "dockerfile_gen"],
        "price_sats": 200,  # vs 260 separately
    },
    "content_machine": {
        "description": "Full content pipeline: blog post + SEO + social posts + email subject lines + hashtags",
        "steps": ["tech_blog", "seo_meta", "social_post", "email_subject", "hashtag_gen"],
        "price_sats": 220,  # vs 250 separately
    },
    "api_launch": {
        "description": "API launch kit: documentation + README + CI/CD config + Dockerfile",
        "steps": ["api_doc", "readme_gen", "cicd_gen", "dockerfile_gen"],
        "price_sats": 180,  # vs 230 separately
    },
}
